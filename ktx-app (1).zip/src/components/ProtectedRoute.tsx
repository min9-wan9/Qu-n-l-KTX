import { useAuth } from "@/lib/auth";
import { Navigate } from "@tanstack/react-router";
import { ReactNode } from "react";
import { AppLayout } from "./AppLayout";

export function ProtectedRoute({ children, adminOnly = false }: { children: ReactNode; adminOnly?: boolean }) {
  const { user, role, loading } = useAuth();
  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Đang tải...</div>
      </div>
    );
  }
  if (!user) return <Navigate to="/login" />;
  if (adminOnly && role !== "admin") return <Navigate to="/dashboard" />;
  return <AppLayout>{children}</AppLayout>;
}
