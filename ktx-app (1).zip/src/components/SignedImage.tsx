import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

function toPath(bucket: string, value: string): string {
  const marker = `/${bucket}/`;
  const idx = value.indexOf(marker);
  if (idx >= 0) return value.slice(idx + marker.length);
  return value;
}

export function useSignedUrl(bucket: string, value: string | null | undefined, expiresIn = 3600) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let active = true;
    if (!value) { setUrl(null); return; }
    const path = toPath(bucket, value);
    supabase.storage.from(bucket).createSignedUrl(path, expiresIn).then(({ data }) => {
      if (active) setUrl(data?.signedUrl ?? null);
    });
    return () => { active = false; };
  }, [bucket, value, expiresIn]);
  return url;
}

interface Props extends React.ImgHTMLAttributes<HTMLImageElement> {
  bucket: string;
  value: string | null | undefined;
  wrapperClassName?: string;
  openOnClick?: boolean;
}

export function SignedImage({ bucket, value, openOnClick, wrapperClassName, ...imgProps }: Props) {
  const url = useSignedUrl(bucket, value);
  if (!url) {
    return <div className={`bg-muted ${wrapperClassName ?? imgProps.className ?? ""}`} />;
  }
  const img = <img {...imgProps} src={url} />;
  if (openOnClick) {
    return <a href={url} target="_blank" rel="noreferrer" className={wrapperClassName}>{img}</a>;
  }
  return img;
}