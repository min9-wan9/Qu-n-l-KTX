import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import { Home, Building2, FileText, Bell, User, LogOut, Users, BarChart3, ClipboardList, Receipt, Wrench } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { ReactNode } from "react";

export function AppLayout({ children }: { children: ReactNode }) {
  const { role, signOut, user } = useAuth();
  const loc = useLocation();
  const nav = useNavigate();

  const studentNav = [
    { to: "/dashboard", label: "Trang chủ", icon: Home },
    { to: "/rooms", label: "Phòng", icon: Building2 },
    { to: "/my-registrations", label: "Đăng ký", icon: FileText },
    { to: "/my-bills", label: "Hóa đơn", icon: Receipt },
    { to: "/maintenance", label: "Sửa chữa", icon: Wrench },
    { to: "/notifications", label: "Thông báo", icon: Bell },
    { to: "/profile", label: "Cá nhân", icon: User },
  ];

  const adminNav = [
    { to: "/admin", label: "Tổng quan", icon: BarChart3 },
    { to: "/admin/rooms", label: "Phòng", icon: Building2 },
    { to: "/admin/registrations", label: "Đơn", icon: ClipboardList },
    { to: "/admin/bills", label: "Hóa đơn", icon: Receipt },
    { to: "/admin/maintenance", label: "Sửa chữa", icon: Wrench },
    { to: "/admin/students", label: "Sinh viên", icon: Users },
    { to: "/profile", label: "Cá nhân", icon: User },
  ];

  const items = role === "admin" ? adminNav : studentNav;

  const handleLogout = async () => {
    await signOut();
    nav({ to: "/login" });
  };

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0 md:pl-64">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex fixed inset-y-0 left-0 w-64 flex-col border-r border-border bg-sidebar p-4">
        <div className="mb-6">
          <h1 className="text-lg font-bold text-sidebar-foreground">🏢 KTX Manager</h1>
          <p className="text-xs text-muted-foreground mt-1">
            {role === "admin" ? "Quản trị viên" : "Sinh viên"}
          </p>
        </div>
        <nav className="flex-1 space-y-1">
          {items.map((item) => {
            const Icon = item.icon;
            const active = loc.pathname === item.to || loc.pathname.startsWith(item.to + "/");
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                  active
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent"
                }`}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-sidebar-border pt-3 mt-3">
          <div className="text-xs text-muted-foreground mb-2 px-2 truncate">{user?.email}</div>
          <Button variant="ghost" size="sm" className="w-full justify-start" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" /> Đăng xuất
          </Button>
        </div>
      </aside>

      {/* Top bar (mobile) */}
      <header className="md:hidden sticky top-0 z-30 bg-card border-b border-border px-4 py-3 flex items-center justify-between">
        <h1 className="font-bold">🏢 KTX</h1>
        <Button variant="ghost" size="sm" onClick={handleLogout}>
          <LogOut className="h-4 w-4" />
        </Button>
      </header>

      {/* Main */}
      <main className="p-4 md:p-8 max-w-6xl mx-auto">{children}</main>

      {/* Bottom nav (mobile) */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-card border-t border-border flex justify-around py-2 safe-area">
        {items.slice(0, 5).map((item) => {
          const Icon = item.icon;
          const active = loc.pathname === item.to || loc.pathname.startsWith(item.to + "/");
          return (
            <Link
              key={item.to}
              to={item.to}
              className={`flex flex-col items-center gap-1 px-3 py-1 rounded-lg text-xs ${
                active ? "text-primary" : "text-muted-foreground"
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="text-[10px]">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
