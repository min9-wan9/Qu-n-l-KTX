import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus, Wrench, X, ImagePlus, Loader2, Home, ArrowRight, Info } from "lucide-react";
import { SignedImage } from "@/components/SignedImage";
import { Link } from "@tanstack/react-router";

export const Route = createFileRoute("/maintenance")({
  component: () => <ProtectedRoute><MyMaintenance /></ProtectedRoute>,
});

const statusLabel: Record<string, { label: string; variant: any }> = {
  pending: { label: "Chờ xử lý", variant: "secondary" },
  in_progress: { label: "Đang xử lý", variant: "default" },
  resolved: { label: "Đã xong", variant: "default" },
  rejected: { label: "Từ chối", variant: "destructive" },
  cancelled: { label: "Đã hủy", variant: "outline" },
};

const categoryLabel: Record<string, string> = {
  electricity: "Điện",
  water: "Nước",
  furniture: "Đồ đạc",
  internet: "Internet",
  other: "Khác",
};

const priorityLabel: Record<string, { label: string; className: string }> = {
  low: { label: "Thấp", className: "text-muted-foreground" },
  medium: { label: "Trung bình", className: "text-primary" },
  high: { label: "Cao", className: "text-destructive" },
};

function MyMaintenance() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "other" as any,
    priority: "medium" as any,
  });

  const handleFiles = async (files: FileList | null) => {
    if (!files || !user) return;
    const arr = Array.from(files).slice(0, 5 - imageUrls.length);
    if (arr.length === 0) return toast.error("Tối đa 5 ảnh");
    setUploading(true);
    const uploaded: string[] = [];
    for (const file of arr) {
      if (!file.type.startsWith("image/")) { toast.error(`${file.name} không phải ảnh`); continue; }
      if (file.size > 5 * 1024 * 1024) { toast.error(`${file.name} > 5MB`); continue; }
      const ext = file.name.split(".").pop() || "jpg";
      const path = `${user.id}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
      const { error } = await supabase.storage.from("maintenance-images").upload(path, file);
      if (error) { toast.error(error.message); continue; }
      uploaded.push(path);
    }
    setImageUrls((p) => [...p, ...uploaded]);
    setUploading(false);
  };

  const removeImage = async (value: string) => {
    const marker = "/maintenance-images/";
    const idx = value.indexOf(marker);
    const path = idx >= 0 ? value.slice(idx + marker.length) : value;
    await supabase.storage.from("maintenance-images").remove([path]);
    setImageUrls((p) => p.filter((u) => u !== value));
  };

  const { data: assign } = useQuery({
    queryKey: ["my-active-room", user?.id],
    queryFn: async () => {
      const { data: a } = await supabase
        .from("room_assignments")
        .select("room_id")
        .eq("user_id", user!.id)
        .eq("is_active", true)
        .maybeSingle();
      if (!a?.room_id) return null;
      const { data: room } = await supabase
        .from("rooms")
        .select("room_number, building")
        .eq("id", a.room_id)
        .maybeSingle();
      return { room_id: a.room_id, rooms: room };
    },
    enabled: !!user,
  });

  const hasRoom = !!assign?.room_id;

  const { data: items, isLoading } = useQuery({
    queryKey: ["my-maintenance", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("maintenance_requests")
        .select("*")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
    enabled: !!user,
  });

  useEffect(() => {
    if (!user) return;
    const ch = supabase
      .channel("my-maintenance")
      .on("postgres_changes", { event: "*", schema: "public", table: "maintenance_requests", filter: `user_id=eq.${user.id}` }, () => {
        qc.invalidateQueries({ queryKey: ["my-maintenance"] });
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user, qc]);

  const submit = async () => {
    if (!form.title.trim() || !form.description.trim()) {
      return toast.error("Vui lòng điền tiêu đề và mô tả");
    }
    const { error } = await supabase.from("maintenance_requests").insert({
      user_id: user!.id,
      room_id: assign?.room_id ?? null,
      title: form.title.trim(),
      description: form.description.trim(),
      category: form.category,
      priority: form.priority,
      image_urls: imageUrls,
    });
    if (error) return toast.error(error.message);
    toast.success("Đã gửi yêu cầu sửa chữa");
    setForm({ title: "", description: "", category: "other", priority: "medium" });
    setImageUrls([]);
    setOpen(false);
    qc.invalidateQueries({ queryKey: ["my-maintenance"] });
  };

  const cancel = async (id: string) => {
    const { error } = await supabase
      .from("maintenance_requests")
      .update({ status: "cancelled" })
      .eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Đã hủy yêu cầu");
    qc.invalidateQueries({ queryKey: ["my-maintenance"] });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">Yêu cầu sửa chữa</h1>
          <p className="text-sm text-muted-foreground">
            {hasRoom
              ? `Phòng ${assign!.rooms?.room_number ?? "—"} · Tòa ${assign!.rooms?.building ?? "—"}`
              : "Bạn chưa được phân phòng"}
          </p>
        </div>
        <Dialog open={open} onOpenChange={(o) => { if (!hasRoom) return; setOpen(o); }}>
          <DialogTrigger asChild>
            <Button size="sm" disabled={!hasRoom} title={hasRoom ? "" : "Bạn cần được phân phòng trước"}>
              <Plus className="h-4 w-4 mr-1" />Tạo
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Tạo yêu cầu sửa chữa</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div>
                <Label>Tiêu đề</Label>
                <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="VD: Bóng đèn bị cháy" />
              </div>
              <div>
                <Label>Mô tả chi tiết</Label>
                <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Mô tả vấn đề càng chi tiết càng tốt..." rows={4} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Loại</Label>
                  <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v as any })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(categoryLabel).map(([k, v]) => (
                        <SelectItem key={k} value={k}>{v}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Mức độ</Label>
                  <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v as any })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(priorityLabel).map(([k, v]) => (
                        <SelectItem key={k} value={k}>{v.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label>Ảnh bằng chứng (tối đa 5)</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                   {imageUrls.map((url) => (
                     <div key={url} className="relative w-20 h-20 rounded-lg overflow-hidden border border-border group">
                       <SignedImage bucket="maintenance-images" value={url} alt="bằng chứng" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => removeImage(url)}
                        className="absolute top-0.5 right-0.5 bg-destructive text-destructive-foreground rounded-full p-0.5"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                  {imageUrls.length < 5 && (
                    <label className="w-20 h-20 rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center cursor-pointer hover:bg-muted text-muted-foreground text-xs gap-1">
                      {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-5 w-5" />}
                      <span>Thêm</span>
                      <input
                        type="file"
                        accept="image/*"
                        multiple
                        className="hidden"
                        disabled={uploading}
                        onChange={(e) => { handleFiles(e.target.files); e.target.value = ""; }}
                      />
                    </label>
                  )}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>Hủy</Button>
              <Button onClick={submit} disabled={uploading}>Gửi</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {!hasRoom && <NoRoomBanner />}

      {!hasRoom ? null : isLoading ? <div>Đang tải...</div> : items?.length === 0 ? (
        <div className="text-muted-foreground bg-card border border-border rounded-xl p-8 text-center">
          <Wrench className="h-8 w-8 mx-auto mb-2 opacity-50" />
          Bạn chưa có yêu cầu nào.
        </div>
      ) : (
        <div className="space-y-3">
          {items?.map((r) => {
            const s = statusLabel[r.status];
            const p = priorityLabel[r.priority];
            return (
              <div key={r.id} className="bg-card border border-border rounded-xl p-4" style={{ boxShadow: "var(--shadow-card)" }}>
                <div className="flex justify-between items-start mb-2 gap-2">
                  <div className="min-w-0">
                    <h3 className="font-semibold truncate">{r.title}</h3>
                    <p className="text-xs text-muted-foreground">
                      {categoryLabel[r.category]} · <span className={p.className}>Ưu tiên {p.label}</span>
                    </p>
                  </div>
                  <Badge variant={s.variant}>{s.label}</Badge>
                </div>
                <p className="text-sm mb-2 whitespace-pre-wrap">{r.description}</p>
                {r.image_urls && r.image_urls.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-2">
                    {r.image_urls.map((url: string) => (
                      <SignedImage key={url} bucket="maintenance-images" value={url} openOnClick wrapperClassName="block w-20 h-20 rounded-lg overflow-hidden border border-border" alt="bằng chứng" className="w-full h-full object-cover" />
                    ))}
                  </div>
                )}
                {r.admin_note && (
                  <p className="text-sm bg-muted p-2 rounded">
                    <span className="text-muted-foreground">Phản hồi: </span>{r.admin_note}
                  </p>
                )}
                <div className="text-xs text-muted-foreground mt-2">
                  {new Date(r.created_at).toLocaleString("vi-VN")}
                  {r.resolved_at && ` · Xong lúc ${new Date(r.resolved_at).toLocaleString("vi-VN")}`}
                </div>
                {r.status === "pending" && (
                  <Button size="sm" variant="outline" className="mt-3" onClick={() => cancel(r.id)}>Hủy yêu cầu</Button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function NoRoomBanner() {
  return (
    <div className="bg-card border border-border rounded-xl p-5 space-y-3" style={{ boxShadow: "var(--shadow-card)" }}>
      <div className="flex items-start gap-3">
        <div className="rounded-lg bg-primary/10 text-primary p-2"><Info className="h-5 w-5" /></div>
        <div className="flex-1">
          <h3 className="font-semibold">Bạn chưa được phân phòng</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Bạn cần có phòng ở trước khi gửi yêu cầu sửa chữa. Hãy làm theo các bước dưới đây để nhận phòng.
          </p>
        </div>
      </div>
      <ol className="text-sm space-y-1 list-decimal pl-5 text-muted-foreground">
        <li>Vào mục <strong className="text-foreground">Danh sách phòng</strong> để xem các phòng còn chỗ.</li>
        <li>Chọn phòng phù hợp và bấm <strong className="text-foreground">Đăng ký</strong>.</li>
        <li>Chờ Ban quản lý duyệt đơn — kết quả sẽ hiển thị ở mục <strong className="text-foreground">Đơn của tôi</strong> và Thông báo.</li>
      </ol>
      <div className="flex gap-2 flex-wrap pt-1">
        <Link to="/rooms"><Button size="sm"><Home className="h-4 w-4 mr-1" />Xem phòng còn chỗ<ArrowRight className="h-4 w-4 ml-1" /></Button></Link>
        <Link to="/my-registrations"><Button size="sm" variant="outline">Đơn của tôi</Button></Link>
      </div>
    </div>
  );
}
