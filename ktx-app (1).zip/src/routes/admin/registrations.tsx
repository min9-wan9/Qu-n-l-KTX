import { SignedImage } from "@/components/SignedImage";
import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export const Route = createFileRoute("/admin/registrations")({
  component: () => <ProtectedRoute adminOnly><AdminRegs /></ProtectedRoute>,
});

const statusLabel: Record<string, { label: string; variant: any }> = {
  pending: { label: "Chờ", variant: "secondary" },
  approved: { label: "Duyệt", variant: "default" },
  rejected: { label: "Từ chối", variant: "destructive" },
  cancelled: { label: "Hủy", variant: "outline" },
};

const categoryLabel: Record<string, string> = {
  hardship: "Hoàn cảnh khó khăn",
  academic: "Xét GPA & Điểm rèn luyện",
  gpa: "Xét GPA",
  conduct: "Điểm rèn luyện",
};

function AdminRegs() {
  const qc = useQueryClient();
  const [tab, setTab] = useState("pending");
  const [acting, setActing] = useState<{ reg: any; action: "approved" | "rejected" } | null>(null);
  const [adminNote, setAdminNote] = useState("");

  const { data: regs, isLoading, error } = useQuery({
    queryKey: ["admin-regs", tab],
    queryFn: async () => {
      let q = supabase.from("registrations").select("*").order("created_at", { ascending: false });
      if (tab !== "all") q = q.eq("status", tab as any);
      const { data: regsData, error: e1 } = await q;
      if (e1) throw e1;
      if (!regsData || regsData.length === 0) return [];

      const userIds = [...new Set(regsData.map((r) => r.user_id))];
      const roomIds = [...new Set(regsData.map((r) => r.room_id))];

      const [{ data: profiles }, { data: rooms }] = await Promise.all([
        supabase.from("profiles").select("id, full_name, student_code, email, phone").in("id", userIds),
        supabase.from("rooms").select("id, room_number, capacity, current_occupancy").in("id", roomIds),
      ]);

      const pMap = new Map((profiles ?? []).map((p) => [p.id, p]));
      const rMap = new Map((rooms ?? []).map((r) => [r.id, r]));

      return regsData.map((r) => ({
        ...r,
        profiles: pMap.get(r.user_id) ?? null,
        rooms: rMap.get(r.room_id) ?? null,
      }));
    },
  });

  useEffect(() => {
    const channel = supabase
      .channel("admin-registrations")
      .on("postgres_changes", { event: "*", schema: "public", table: "registrations" }, (payload) => {
        qc.invalidateQueries({ queryKey: ["admin-regs"] });
        if (payload.eventType === "INSERT") {
          toast.info("Có đơn đăng ký mới");
        }
      })
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc]);

  const handle = async () => {
    if (!acting) return;
    const { reg, action } = acting;

    const { error: e1 } = await supabase
      .from("registrations")
      .update({ status: action, admin_note: adminNote || null })
      .eq("id", reg.id);
    if (e1) return toast.error(e1.message);

    if (action === "approved") {
      const room = reg.rooms;
      if (room && room.current_occupancy >= room.capacity) {
        toast.error("Phòng đã đầy");
        return;
      }
      await supabase.from("room_assignments").insert({
        user_id: reg.user_id,
        room_id: reg.room_id,
        is_active: true,
      });
      if (room) {
        await supabase.from("rooms").update({ current_occupancy: room.current_occupancy + 1 }).eq("id", reg.room_id);
      }
    }

    await supabase.from("notifications").insert({
      user_id: reg.user_id,
      title: action === "approved" ? "Đơn đăng ký đã được duyệt" : "Đơn đăng ký bị từ chối",
      message: `Phòng ${reg.rooms?.room_number ?? ""}: ${action === "approved" ? "Chúc mừng, bạn đã được phân phòng." : "Đơn của bạn không được duyệt."}${adminNote ? " Ghi chú: " + adminNote : ""}`,
      type: action === "approved" ? "success" : "warning",
    });

    toast.success("Đã xử lý");
    setActing(null);
    setAdminNote("");
    qc.invalidateQueries({ queryKey: ["admin-regs"] });
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Quản lý đơn đăng ký</h1>
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="pending">Chờ duyệt</TabsTrigger>
          <TabsTrigger value="approved">Đã duyệt</TabsTrigger>
          <TabsTrigger value="rejected">Từ chối</TabsTrigger>
          <TabsTrigger value="all">Tất cả</TabsTrigger>
        </TabsList>
        <TabsContent value={tab} className="space-y-3 mt-4">
          {isLoading && <div className="text-muted-foreground">Đang tải...</div>}
          {error && <div className="text-destructive text-sm">{(error as any).message}</div>}
          {!isLoading && regs?.length === 0 && <div className="text-muted-foreground">Không có đơn nào.</div>}
          {regs?.map((r: any) => {
            const s = statusLabel[r.status];
            return (
              <div key={r.id} className="bg-card border border-border rounded-xl p-4" style={{ boxShadow: "var(--shadow-card)" }}>
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-semibold">{r.profiles?.full_name || "Sinh viên"} → Phòng {r.rooms?.room_number ?? "—"}</h3>
                    <p className="text-xs text-muted-foreground">{r.profiles?.email} · MSV: {r.profiles?.student_code || "—"}</p>
                  </div>
                  <Badge variant={s.variant}>{s.label}</Badge>
                </div>
                {r.note && <p className="text-sm mb-2"><span className="text-muted-foreground">Ghi chú SV:</span> {r.note}</p>}
                {r.category && (
                  <div className="text-sm mb-2 space-y-1">
                    <div><Badge variant="outline">{categoryLabel[r.category]}</Badge></div>
                    {r.category === "academic" && (
                      <div className="flex gap-4">
                        {r.gpa != null && <span>GPA: <strong>{r.gpa}</strong></span>}
                        {r.conduct_score != null && <span>ĐRL: <strong>{r.conduct_score}</strong></span>}
                      </div>
                    )}
                    {r.category === "gpa" && r.gpa != null && <div>GPA: <strong>{r.gpa}</strong></div>}
                    {r.category === "conduct" && r.conduct_score != null && <div>Điểm rèn luyện: <strong>{r.conduct_score}</strong></div>}
                    {r.category === "hardship" && r.hardship_proof && <div className="text-muted-foreground">Minh chứng: {r.hardship_proof}</div>}
                    {r.proof_image_url && (
                      <div className="pt-2">
                        <div className="text-xs text-muted-foreground mb-1">Ảnh minh chứng:</div>
                        <SignedImage bucket="registration-proofs" value={r.proof_image_url} openOnClick alt="Minh chứng" className="max-h-48 rounded border border-border hover:opacity-90 transition" />
                      </div>
                    )}
                  </div>
                )}
                {(r.start_date || r.end_date) && (
                  <p className="text-xs text-muted-foreground mb-1">Thời hạn ở: {r.start_date} → {r.end_date}</p>
                )}
                {r.admin_note && <p className="text-sm mb-2 bg-muted p-2 rounded"><span className="text-muted-foreground">Phản hồi:</span> {r.admin_note}</p>}
                <p className="text-xs text-muted-foreground">Gửi: {new Date(r.created_at).toLocaleString("vi-VN")}</p>
                {r.status === "pending" && (
                  <div className="flex gap-2 mt-3">
                    <Button size="sm" onClick={() => setActing({ reg: r, action: "approved" })}>Duyệt</Button>
                    <Button size="sm" variant="destructive" onClick={() => setActing({ reg: r, action: "rejected" })}>Từ chối</Button>
                  </div>
                )}
              </div>
            );
          })}
        </TabsContent>
      </Tabs>

      <Dialog open={!!acting} onOpenChange={(o) => !o && setActing(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{acting?.action === "approved" ? "Duyệt đơn" : "Từ chối đơn"}</DialogTitle>
          </DialogHeader>
          <Textarea placeholder="Ghi chú phản hồi (tùy chọn)" value={adminNote} onChange={(e) => setAdminNote(e.target.value)} />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setActing(null)}>Hủy</Button>
            <Button onClick={handle}>Xác nhận</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
