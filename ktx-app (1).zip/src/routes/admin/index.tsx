import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Building2, Users, ClipboardList, TrendingUp, Wallet, AlertTriangle } from "lucide-react";
import { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/admin/")({
  component: () => <ProtectedRoute adminOnly><AdminDash /></ProtectedRoute>,
});

const fmt = (n: number) => Number(n || 0).toLocaleString("vi-VN") + "đ";

function currentPeriod() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function AdminDash() {
  const [period, setPeriod] = useState<string>(currentPeriod());
  const qc = useQueryClient();

  useEffect(() => {
    const ch = supabase
      .channel("admin-dashboard")
      .on("postgres_changes", { event: "*", schema: "public", table: "registrations" }, () => {
        qc.invalidateQueries({ queryKey: ["admin-stats"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "room_assignments" }, () => {
        qc.invalidateQueries({ queryKey: ["admin-stats"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "bills" }, () => {
        qc.invalidateQueries({ queryKey: ["admin-finance"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "payments" }, () => {
        qc.invalidateQueries({ queryKey: ["admin-finance"] });
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [qc]);

  const { data: stats } = useQuery({
    queryKey: ["admin-stats"],
    queryFn: async () => {
      const [rooms, regs, students, assigns] = await Promise.all([
        supabase.from("rooms").select("capacity, current_occupancy"),
        supabase.from("registrations").select("status"),
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("room_assignments").select("id", { count: "exact", head: true }).eq("is_active", true),
      ]);
      const totalCap = rooms.data?.reduce((s, r) => s + r.capacity, 0) ?? 0;
      const totalOcc = rooms.data?.reduce((s, r) => s + r.current_occupancy, 0) ?? 0;
      const pendingRegs = regs.data?.filter((r) => r.status === "pending").length ?? 0;
      return {
        rooms: rooms.data?.length ?? 0,
        totalCap,
        totalOcc,
        occRate: totalCap > 0 ? Math.round((totalOcc / totalCap) * 100) : 0,
        pendingRegs,
        students: students.count ?? 0,
        activeAssignments: assigns.count ?? 0,
      };
    },
  });

  const { data: finance } = useQuery({
    queryKey: ["admin-finance", period],
    queryFn: async () => {
      const { data: bills } = await supabase
        .from("bills")
        .select("id, room_id, total_amount, paid_amount, status")
        .eq("period", period);

      const billList = bills ?? [];
      const totalBilled = billList.reduce((s, b) => s + Number(b.total_amount), 0);
      const totalPaid = billList.reduce((s, b) => s + Number(b.paid_amount), 0);
      const totalDebt = totalBilled - totalPaid;
      const overdue = billList.filter((b) => b.status === "overdue").length;
      const unpaid = billList.filter((b) => b.status !== "paid").length;

      // group by room
      const roomIds = [...new Set(billList.map((b) => b.room_id))];
      const { data: rooms } = roomIds.length
        ? await supabase.from("rooms").select("id, room_number, building, floor").in("id", roomIds)
        : { data: [] as any[] };
      const rMap = new Map((rooms ?? []).map((r) => [r.id, r]));

      const byRoom = new Map<string, { room: any; billed: number; paid: number; debt: number; bills: number }>();
      for (const b of billList) {
        const cur = byRoom.get(b.room_id) ?? { room: rMap.get(b.room_id), billed: 0, paid: 0, debt: 0, bills: 0 };
        cur.billed += Number(b.total_amount);
        cur.paid += Number(b.paid_amount);
        cur.debt = cur.billed - cur.paid;
        cur.bills += 1;
        byRoom.set(b.room_id, cur);
      }
      const roomRows = [...byRoom.values()].sort((a, b) => b.debt - a.debt);
      const topDebt = roomRows.filter((r) => r.debt > 0).slice(0, 5);

      return { totalBilled, totalPaid, totalDebt, overdue, unpaid, billCount: billList.length, roomRows, topDebt };
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Tổng quan</h1>
        <p className="text-sm text-muted-foreground">Thống kê hệ thống KTX</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat icon={Building2} label="Tổng số phòng" value={stats?.rooms ?? 0} />
        <Stat icon={TrendingUp} label="Tỷ lệ lấp đầy" value={`${stats?.occRate ?? 0}%`} sub={`${stats?.totalOcc}/${stats?.totalCap} chỗ`} />
        <Stat icon={ClipboardList} label="Đơn chờ duyệt" value={stats?.pendingRegs ?? 0} />
        <Stat icon={Users} label="Sinh viên" value={stats?.students ?? 0} sub={`${stats?.activeAssignments} đang ở`} />
      </div>

      <div className="bg-card border border-border rounded-xl p-5 space-y-4" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-end justify-between flex-wrap gap-3">
          <div>
            <h2 className="text-lg font-bold">Tài chính theo tháng</h2>
            <p className="text-xs text-muted-foreground">Doanh thu, công nợ kỳ {period}</p>
          </div>
          <div>
            <Label className="text-xs">Kỳ (tháng)</Label>
            <Input type="month" value={period} onChange={(e) => setPeriod(e.target.value || currentPeriod())} className="w-44" />
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat icon={Wallet} label="Tổng phải thu" value={fmt(finance?.totalBilled ?? 0)} sub={`${finance?.billCount ?? 0} hóa đơn`} />
          <Stat icon={TrendingUp} label="Đã thu" value={fmt(finance?.totalPaid ?? 0)} />
          <Stat icon={AlertTriangle} label="Còn nợ" value={fmt(finance?.totalDebt ?? 0)} sub={`${finance?.unpaid ?? 0} chưa xong`} />
          <Stat icon={AlertTriangle} label="Hóa đơn quá hạn" value={finance?.overdue ?? 0} />
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <h2 className="text-lg font-bold mb-3">Top 5 phòng nợ nhiều nhất</h2>
        {(!finance?.topDebt || finance.topDebt.length === 0) ? (
          <p className="text-sm text-muted-foreground">Không có phòng nào nợ trong kỳ {period}.</p>
        ) : (
          <div className="space-y-2">
            {finance.topDebt.map((r, i) => (
              <div key={r.room?.id ?? i} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <div>
                  <div className="font-semibold">#{i + 1} · Phòng {r.room?.room_number ?? "—"}</div>
                  <div className="text-xs text-muted-foreground">Tòa {r.room?.building ?? "—"} · Tầng {r.room?.floor ?? "—"} · {r.bills} hóa đơn</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-destructive">{fmt(r.debt)}</div>
                  <div className="text-xs text-muted-foreground">Đã thu {fmt(r.paid)}/{fmt(r.billed)}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-card border border-border rounded-xl p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <h2 className="text-lg font-bold mb-3">Công nợ tất cả phòng (kỳ {period})</h2>
        {(!finance?.roomRows || finance.roomRows.length === 0) ? (
          <p className="text-sm text-muted-foreground">Chưa có hóa đơn nào trong kỳ này.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-xs text-muted-foreground">
                <tr className="border-b border-border">
                  <th className="text-left py-2">Phòng</th>
                  <th className="text-right py-2">Phải thu</th>
                  <th className="text-right py-2">Đã thu</th>
                  <th className="text-right py-2">Còn nợ</th>
                </tr>
              </thead>
              <tbody>
                {finance.roomRows.map((r, i) => (
                  <tr key={r.room?.id ?? i} className="border-b border-border/50">
                    <td className="py-2">
                      <div className="font-medium">P.{r.room?.room_number ?? "—"}</div>
                      <div className="text-xs text-muted-foreground">T{r.room?.floor ?? "—"} · Tòa {r.room?.building ?? "—"}</div>
                    </td>
                    <td className="text-right py-2">{fmt(r.billed)}</td>
                    <td className="text-right py-2 text-primary">{fmt(r.paid)}</td>
                    <td className={"text-right py-2 font-semibold " + (r.debt > 0 ? "text-destructive" : "text-muted-foreground")}>{fmt(r.debt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({ icon: Icon, label, value, sub }: any) {
  return (
    <div className="bg-card border border-border rounded-xl p-5" style={{ boxShadow: "var(--shadow-card)" }}>
      <Icon className="h-5 w-5 text-primary mb-2" />
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-2xl font-bold mt-1">{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-1">{sub}</div>}
    </div>
  );
}
