import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Plus, Trash2, Wallet } from "lucide-react";

export const Route = createFileRoute("/admin/bills")({
  component: () => <ProtectedRoute adminOnly><AdminBills /></ProtectedRoute>,
});

const statusBadge: Record<string, { label: string; variant: any }> = {
  unpaid: { label: "Chưa TT", variant: "secondary" },
  partial: { label: "Một phần", variant: "outline" },
  paid: { label: "Đã TT", variant: "default" },
  overdue: { label: "Quá hạn", variant: "destructive" },
};

const fmt = (n: number) => n.toLocaleString("vi-VN") + " ₫";

function AdminBills() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [payOpen, setPayOpen] = useState<any>(null);

  const { data: bills, isLoading } = useQuery({
    queryKey: ["admin-bills"],
    queryFn: async () => {
      const { data: bs, error } = await supabase.from("bills").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      if (!bs?.length) return [];
      const userIds = [...new Set(bs.map((b) => b.user_id))];
      const roomIds = [...new Set(bs.map((b) => b.room_id))];
      const [{ data: profiles }, { data: rooms }] = await Promise.all([
        supabase.from("profiles").select("id, full_name, email").in("id", userIds),
        supabase.from("rooms").select("id, room_number").in("id", roomIds),
      ]);
      const pMap = new Map((profiles ?? []).map((p) => [p.id, p]));
      const rMap = new Map((rooms ?? []).map((r) => [r.id, r]));
      return bs.map((b) => ({ ...b, profile: pMap.get(b.user_id), room: rMap.get(b.room_id) }));
    },
  });

  const handleDelete = async (id: string) => {
    if (!confirm("Xóa hóa đơn này?")) return;
    const { error } = await supabase.from("bills").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Đã xóa");
    qc.invalidateQueries({ queryKey: ["admin-bills"] });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-3">
        <h1 className="text-2xl font-bold">Hóa đơn ({bills?.length ?? 0})</h1>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="h-4 w-4 mr-1" />Tạo hóa đơn</Button>
          </DialogTrigger>
          <CreateBillDialog onClose={() => { setOpen(false); qc.invalidateQueries({ queryKey: ["admin-bills"] }); }} />
        </Dialog>
      </div>

      {isLoading && <p className="text-muted-foreground">Đang tải...</p>}
      {!isLoading && bills?.length === 0 && <p className="text-muted-foreground">Chưa có hóa đơn nào.</p>}

      <div className="space-y-3">
        {bills?.map((b: any) => {
          const s = statusBadge[b.status];
          const remaining = Number(b.total_amount) - Number(b.paid_amount);
          return (
            <div key={b.id} className="bg-card border border-border rounded-xl p-4" style={{ boxShadow: "var(--shadow-card)" }}>
              <div className="flex justify-between items-start mb-2 gap-2">
                <div>
                  <h3 className="font-semibold">{b.profile?.full_name || "—"} · Phòng {b.room?.room_number ?? "—"}</h3>
                  <p className="text-xs text-muted-foreground">{b.profile?.email} · Kỳ: {b.period}</p>
                </div>
                <Badge variant={s.variant}>{s.label}</Badge>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs my-2">
                <div><span className="text-muted-foreground">Phòng:</span> {fmt(Number(b.room_fee))}</div>
                <div><span className="text-muted-foreground">Điện:</span> {b.electricity_new - b.electricity_old} kWh · {fmt((b.electricity_new - b.electricity_old) * Number(b.electricity_rate))}</div>
                <div><span className="text-muted-foreground">Nước:</span> {b.water_new - b.water_old} m³ · {fmt((b.water_new - b.water_old) * Number(b.water_rate))}</div>
                <div><span className="text-muted-foreground">Khác:</span> {fmt(Number(b.other_fee))}</div>
              </div>
              <div className="flex justify-between items-center text-sm border-t border-border pt-2">
                <div>
                  <div><span className="text-muted-foreground">Tổng:</span> <span className="font-bold">{fmt(Number(b.total_amount))}</span></div>
                  <div className="text-xs"><span className="text-muted-foreground">Đã TT:</span> {fmt(Number(b.paid_amount))} · <span className="text-muted-foreground">Còn:</span> <span className="text-destructive font-semibold">{fmt(remaining)}</span></div>
                </div>
                <div className="flex gap-2">
                  {remaining > 0 && (
                    <Button size="sm" variant="outline" onClick={() => setPayOpen(b)}>
                      <Wallet className="h-4 w-4 mr-1" />Thu tiền
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" onClick={() => handleDelete(b.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              {b.due_date && <p className="text-xs text-muted-foreground mt-1">Hạn: {new Date(b.due_date).toLocaleDateString("vi-VN")}</p>}
            </div>
          );
        })}
      </div>

      <Dialog open={!!payOpen} onOpenChange={(o) => !o && setPayOpen(null)}>
        {payOpen && <PayDialog bill={payOpen} onClose={() => { setPayOpen(null); qc.invalidateQueries({ queryKey: ["admin-bills"] }); }} />}
      </Dialog>
    </div>
  );
}

function CreateBillDialog({ onClose }: { onClose: () => void }) {
  const [userId, setUserId] = useState("");
  const [period, setPeriod] = useState(new Date().toISOString().slice(0, 7));
  const [roomFee, setRoomFee] = useState("0");
  const [eOld, setEOld] = useState("0");
  const [eNew, setENew] = useState("0");
  const [eRate, setERate] = useState("3500");
  const [wOld, setWOld] = useState("0");
  const [wNew, setWNew] = useState("0");
  const [wRate, setWRate] = useState("15000");
  const [otherFee, setOtherFee] = useState("0");
  const [dueDate, setDueDate] = useState("");
  const [note, setNote] = useState("");

  const { data: students } = useQuery({
    queryKey: ["bill-students"],
    queryFn: async () => {
      const { data: assigns } = await supabase.from("room_assignments").select("user_id, room_id, rooms(room_number, monthly_price)").eq("is_active", true);
      if (!assigns?.length) return [];
      const ids = assigns.map((a) => a.user_id);
      const { data: profiles } = await supabase.from("profiles").select("id, full_name, email").in("id", ids);
      const pMap = new Map((profiles ?? []).map((p) => [p.id, p]));
      return assigns.map((a: any) => ({ ...a, profile: pMap.get(a.user_id) }));
    },
  });

  const selected = students?.find((s) => s.user_id === userId);

  const total = useMemo(() => {
    return Number(roomFee || 0) + (Number(eNew || 0) - Number(eOld || 0)) * Number(eRate || 0) + (Number(wNew || 0) - Number(wOld || 0)) * Number(wRate || 0) + Number(otherFee || 0);
  }, [roomFee, eOld, eNew, eRate, wOld, wNew, wRate, otherFee]);

  const handleStudentSelect = (id: string) => {
    setUserId(id);
    const s = students?.find((x) => x.user_id === id);
    if (s?.rooms?.monthly_price) setRoomFee(String(s.rooms.monthly_price));
  };

  const submit = async () => {
    if (!userId || !selected) return toast.error("Chọn sinh viên");
    if (Number(eNew) < Number(eOld) || Number(wNew) < Number(wOld)) return toast.error("Chỉ số mới phải >= chỉ số cũ");

    const { error } = await supabase.from("bills").insert({
      user_id: userId,
      room_id: selected.room_id,
      period,
      room_fee: Number(roomFee),
      electricity_old: Number(eOld),
      electricity_new: Number(eNew),
      electricity_rate: Number(eRate),
      water_old: Number(wOld),
      water_new: Number(wNew),
      water_rate: Number(wRate),
      other_fee: Number(otherFee),
      total_amount: total,
      due_date: dueDate || null,
      note: note || null,
    });
    if (error) return toast.error(error.message);

    await supabase.from("notifications").insert({
      user_id: userId,
      title: "Hóa đơn mới",
      message: `Hóa đơn kỳ ${period}: ${fmt(total)}`,
      type: "info",
    });

    toast.success("Đã tạo hóa đơn");
    onClose();
  };

  return (
    <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
      <DialogHeader><DialogTitle>Tạo hóa đơn</DialogTitle></DialogHeader>
      <div className="space-y-3">
        <div>
          <Label>Sinh viên (đã ở phòng)</Label>
          <Select value={userId} onValueChange={handleStudentSelect}>
            <SelectTrigger><SelectValue placeholder="Chọn sinh viên" /></SelectTrigger>
            <SelectContent>
              {students?.map((s: any) => (
                <SelectItem key={s.user_id} value={s.user_id}>
                  {s.profile?.full_name || s.profile?.email} · P.{s.rooms?.room_number}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div><Label>Kỳ (YYYY-MM)</Label><Input value={period} onChange={(e) => setPeriod(e.target.value)} /></div>
          <div><Label>Tiền phòng</Label><Input type="number" value={roomFee} onChange={(e) => setRoomFee(e.target.value)} /></div>
        </div>
        <div className="border-t border-border pt-3">
          <p className="font-semibold text-sm mb-2">⚡ Điện</p>
          <div className="grid grid-cols-3 gap-2">
            <div><Label className="text-xs">Cũ</Label><Input type="number" value={eOld} onChange={(e) => setEOld(e.target.value)} /></div>
            <div><Label className="text-xs">Mới</Label><Input type="number" value={eNew} onChange={(e) => setENew(e.target.value)} /></div>
            <div><Label className="text-xs">Đơn giá</Label><Input type="number" value={eRate} onChange={(e) => setERate(e.target.value)} /></div>
          </div>
        </div>
        <div className="border-t border-border pt-3">
          <p className="font-semibold text-sm mb-2">💧 Nước</p>
          <div className="grid grid-cols-3 gap-2">
            <div><Label className="text-xs">Cũ</Label><Input type="number" value={wOld} onChange={(e) => setWOld(e.target.value)} /></div>
            <div><Label className="text-xs">Mới</Label><Input type="number" value={wNew} onChange={(e) => setWNew(e.target.value)} /></div>
            <div><Label className="text-xs">Đơn giá</Label><Input type="number" value={wRate} onChange={(e) => setWRate(e.target.value)} /></div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div><Label>Phí khác</Label><Input type="number" value={otherFee} onChange={(e) => setOtherFee(e.target.value)} /></div>
          <div><Label>Hạn TT</Label><Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} /></div>
        </div>
        <div><Label>Ghi chú</Label><Input value={note} onChange={(e) => setNote(e.target.value)} /></div>
        <div className="bg-muted p-3 rounded-lg text-center">
          <span className="text-muted-foreground text-sm">Tổng: </span>
          <span className="text-xl font-bold text-primary">{fmt(total)}</span>
        </div>
      </div>
      <DialogFooter>
        <Button variant="ghost" onClick={onClose}>Hủy</Button>
        <Button onClick={submit}>Tạo</Button>
      </DialogFooter>
    </DialogContent>
  );
}

function PayDialog({ bill, onClose }: { bill: any; onClose: () => void }) {
  const remaining = Number(bill.total_amount) - Number(bill.paid_amount);
  const [amount, setAmount] = useState(String(remaining));
  const [method, setMethod] = useState<"cash" | "bank_transfer" | "momo" | "other">("cash");
  const [note, setNote] = useState("");

  const submit = async () => {
    const amt = Number(amount);
    if (!amt || amt <= 0) return toast.error("Số tiền không hợp lệ");
    if (amt > remaining) return toast.error("Vượt quá số còn lại");

    const { error: e1 } = await supabase.from("payments").insert({
      bill_id: bill.id,
      user_id: bill.user_id,
      amount: amt,
      method,
      note: note || null,
    });
    if (e1) return toast.error(e1.message);

    const newPaid = Number(bill.paid_amount) + amt;
    const newStatus = newPaid >= Number(bill.total_amount) ? "paid" : "partial";
    await supabase.from("bills").update({ paid_amount: newPaid, status: newStatus }).eq("id", bill.id);

    await supabase.from("notifications").insert({
      user_id: bill.user_id,
      title: "Thanh toán đã ghi nhận",
      message: `Đã nhận ${fmt(amt)} cho hóa đơn kỳ ${bill.period}`,
      type: "success",
    });

    toast.success("Đã ghi nhận");
    onClose();
  };

  return (
    <DialogContent>
      <DialogHeader><DialogTitle>Thu tiền · {bill.profile?.full_name}</DialogTitle></DialogHeader>
      <div className="space-y-3">
        <div className="bg-muted p-3 rounded text-sm">
          Còn phải thu: <span className="font-bold text-destructive">{fmt(remaining)}</span>
        </div>
        <div><Label>Số tiền</Label><Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} /></div>
        <div>
          <Label>Phương thức</Label>
          <Select value={method} onValueChange={(v) => setMethod(v as any)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="cash">Tiền mặt</SelectItem>
              <SelectItem value="bank_transfer">Chuyển khoản</SelectItem>
              <SelectItem value="momo">MoMo</SelectItem>
              <SelectItem value="other">Khác</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div><Label>Ghi chú</Label><Input value={note} onChange={(e) => setNote(e.target.value)} /></div>
      </div>
      <DialogFooter>
        <Button variant="ghost" onClick={onClose}>Hủy</Button>
        <Button onClick={submit}>Xác nhận</Button>
      </DialogFooter>
    </DialogContent>
  );
}
