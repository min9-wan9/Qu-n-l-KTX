import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Pencil } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/rooms")({
  component: () => <ProtectedRoute adminOnly><AdminRooms /></ProtectedRoute>,
});

const FACILITY_OPTIONS = [
  "Giường tầng","Giường đơn","Bàn học","Bàn học riêng","Tủ quần áo",
  "Đèn LED","Quạt trần","Máy lạnh","Nóng lạnh","Nhà vệ sinh chung",
  "Nhà vệ sinh khép kín","Wifi tốc độ cao","Tủ lạnh mini",
];

function AdminRooms() {
  const qc = useQueryClient();
  const [editing, setEditing] = useState<any>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>(null);

  const { data: rooms } = useQuery({
    queryKey: ["admin-rooms"],
    queryFn: async () => {
      const { data } = await supabase.from("rooms").select("*").order("room_number");
      return data ?? [];
    },
  });

  const openEdit = (r: any) => { setEditing(r); setForm({ ...r, facilities: r.facilities ?? [] }); setOpen(true); };

  const toggleFacility = (f: string) => {
    const list: string[] = form.facilities ?? [];
    setForm({ ...form, facilities: list.includes(f) ? list.filter((x) => x !== f) : [...list, f] });
  };

  const save = async () => {
    const payload = {
      room_type: form.room_type,
      capacity: Number(form.capacity),
      monthly_price: Number(form.monthly_price),
      description: form.description || null,
      facilities: form.facilities ?? [],
    };
    const { error } = await supabase.from("rooms").update(payload).eq("id", editing.id);
    if (error) return toast.error(error.message);
    toast.success("Đã cập nhật");
    setOpen(false);
    qc.invalidateQueries({ queryKey: ["admin-rooms"] });
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Quản lý phòng</h1>
        <p className="text-sm text-muted-foreground">Toà A có {rooms?.length ?? 0} phòng cố định. Bạn chỉ có thể chỉnh sửa thông tin phòng.</p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {rooms?.map((r) => (
          <div key={r.id} className="bg-card border border-border rounded-xl p-4" style={{ boxShadow: "var(--shadow-card)" }}>
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="font-bold">Phòng {r.room_number}</h3>
                <p className="text-xs text-muted-foreground">Tòa {r.building} · Tầng {r.floor}</p>
              </div>
              <Badge variant={r.room_type === "vip" ? "default" : "secondary"}>
                {r.room_type === "vip" ? "VIP" : "Tiêu chuẩn"}
              </Badge>
            </div>
            <div className="text-sm space-y-1 mb-3">
              <div>Sức chứa: {r.current_occupancy}/{r.capacity}</div>
              <div>Giá: {Number(r.monthly_price).toLocaleString()}đ</div>
              {r.facilities?.length > 0 && (
                <div className="text-xs text-muted-foreground">
                  CSVC: {r.facilities.slice(0, 3).join(", ")}{r.facilities.length > 3 ? `, +${r.facilities.length - 3}` : ""}
                </div>
              )}
            </div>
            <Button size="sm" variant="outline" onClick={() => openEdit(r)}>
              <Pencil className="h-3 w-3 mr-1" /> Sửa
            </Button>
          </div>
        ))}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        {form && (
          <DialogContent className="max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Sửa phòng {form.room_number}</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Loại phòng</Label>
                  <Select value={form.room_type} onValueChange={(v) => setForm({ ...form, room_type: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">Tiêu chuẩn</SelectItem>
                      <SelectItem value="vip">VIP (cao cấp)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Sức chứa (SV)</Label>
                  <Select value={String(form.capacity)} onValueChange={(v) => setForm({ ...form, capacity: Number(v) })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="4">4 sinh viên</SelectItem>
                      <SelectItem value="8">8 sinh viên</SelectItem>
                      <SelectItem value="12">12 sinh viên</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div><Label>Giá / tháng (VNĐ)</Label><Input type="number" value={form.monthly_price} onChange={(e) => setForm({ ...form, monthly_price: e.target.value })} /></div>
              <div>
                <Label>Cơ sở vật chất</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {FACILITY_OPTIONS.map((f) => {
                    const checked = (form.facilities ?? []).includes(f);
                    return (
                      <label key={f} className="flex items-center gap-2 text-sm cursor-pointer">
                        <input type="checkbox" checked={checked} onChange={() => toggleFacility(f)} />
                        {f}
                      </label>
                    );
                  })}
                </div>
              </div>
              <div><Label>Mô tả</Label><Textarea value={form.description ?? ""} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>Hủy</Button>
              <Button onClick={save}>Lưu</Button>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
}
