import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export const Route = createFileRoute("/admin/students")({
  component: () => <ProtectedRoute adminOnly><AdminStudents /></ProtectedRoute>,
});

function AdminStudents() {
  const [search, setSearch] = useState("");
  const { data: students } = useQuery({
    queryKey: ["admin-students"],
    queryFn: async () => {
      const { data: profiles } = await supabase.from("profiles").select("*").order("full_name");
      const { data: assignments } = await supabase
        .from("room_assignments")
        .select("user_id, rooms(room_number, building)")
        .eq("is_active", true);
      const map = new Map((assignments ?? []).map((a: any) => [a.user_id, a.rooms]));
      return (profiles ?? []).map((p) => ({ ...p, room: map.get(p.id) }));
    },
  });

  const filtered = students?.filter((s) => {
    const q = search.toLowerCase();
    return !q || s.full_name?.toLowerCase().includes(q) || s.email?.toLowerCase().includes(q) || s.student_code?.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-3">
        <h1 className="text-2xl font-bold">Sinh viên ({students?.length ?? 0})</h1>
        <Input placeholder="Tìm tên, email, MSV..." className="max-w-xs" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>
      <div className="bg-card border border-border rounded-xl overflow-hidden" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="text-left p-3">Họ tên</th>
                <th className="text-left p-3">Email</th>
                <th className="text-left p-3">MSV</th>
                <th className="text-left p-3">Lớp</th>
                <th className="text-left p-3">Phòng</th>
              </tr>
            </thead>
            <tbody>
              {filtered?.map((s: any) => (
                <tr key={s.id} className="border-t border-border">
                  <td className="p-3 font-medium">{s.full_name || "—"}</td>
                  <td className="p-3 text-muted-foreground">{s.email}</td>
                  <td className="p-3">{s.student_code || "—"}</td>
                  <td className="p-3">{s.class_name || "—"}</td>
                  <td className="p-3">
                    {s.room ? <Badge>{s.room.room_number}</Badge> : <span className="text-muted-foreground text-xs">Chưa có</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
