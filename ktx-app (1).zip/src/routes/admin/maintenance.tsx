import { SignedImage } from "@/components/SignedImage";
import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/maintenance")({
  component: () => <ProtectedRoute adminOnly><AdminMaintenance /></ProtectedRoute>,
});

const statusLabel: Record<string, { label: string; variant: any }> = {
  pending: { label: "Chờ", variant: "secondary" },
  in_progress: { label: "Đang xử lý", variant: "default" },
  resolved: { label: "Đã xong", variant: "default" },
  rejected: { label: "Từ chối", variant: "destructive" },
  cancelled: { label: "Hủy", variant: "outline" },
};

const categoryLabel: Record<string, string> = {
  electricity: "Điện",
  water: "Nước",
  furniture: "Đồ đạc",
  internet: "Internet",
  other: "Khác",
};

const priorityLabel: Record<string, { label: string; className: string }> = {
  low: { label: "Thấp", className: "text-muted-foreground" },
  medium: { label: "Trung bình", className: "text-primary" },
  high: { label: "Cao", className: "text-destructive font-semibold" },
};

function AdminMaintenance() {
  const qc = useQueryClient();
  const [tab, setTab] = useState("pending");
  const [editing, setEditing] = useState<any>(null);
  const [newStatus, setNewStatus] = useState<string>("in_progress");
  const [adminNote, setAdminNote] = useState("");

  const { data: items, isLoading } = useQuery({
    queryKey: ["admin-maintenance", tab],
    queryFn: async () => {
      let q = supabase.from("maintenance_requests").select("*").order("created_at", { ascending: false });
      if (tab !== "all") q = q.eq("status", tab as any);
      const { data, error } = await q;
      if (error) throw error;
      if (!data || data.length === 0) return [];

      const userIds = [...new Set(data.map((r) => r.user_id))];
      const roomIds = [...new Set(data.map((r) => r.room_id).filter(Boolean))] as string[];
      const [{ data: profiles }, { data: rooms }] = await Promise.all([
        supabase.from("profiles").select("id, full_name, student_code, phone").in("id", userIds),
        roomIds.length
          ? supabase.from("rooms").select("id, room_number, building, floor").in("id", roomIds)
          : Promise.resolve({ data: [] as any[] }),
      ]);
      const pMap = new Map((profiles ?? []).map((p) => [p.id, p]));
      const rMap = new Map((rooms ?? []).map((r) => [r.id, r]));
      return data.map((r) => ({ ...r, profile: pMap.get(r.user_id), room: r.room_id ? rMap.get(r.room_id) : null }));
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel("admin-maintenance")
      .on("postgres_changes", { event: "*", schema: "public", table: "maintenance_requests" }, (payload) => {
        qc.invalidateQueries({ queryKey: ["admin-maintenance"] });
        if (payload.eventType === "INSERT") toast.info("Có yêu cầu sửa chữa mới");
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [qc]);

  const save = async () => {
    if (!editing) return;
    const update: any = { status: newStatus, admin_note: adminNote || null };
    if (newStatus === "resolved") update.resolved_at = new Date().toISOString();
    const { error } = await supabase.from("maintenance_requests").update(update).eq("id", editing.id);
    if (error) return toast.error(error.message);

    await supabase.from("notifications").insert({
      user_id: editing.user_id,
      title: "Cập nhật yêu cầu sửa chữa",
      message: `Yêu cầu "${editing.title}": ${statusLabel[newStatus]?.label}.${adminNote ? " Ghi chú: " + adminNote : ""}`,
      type: newStatus === "resolved" ? "success" : newStatus === "rejected" ? "warning" : "info",
    });

    toast.success("Đã cập nhật");
    setEditing(null);
    setAdminNote("");
    qc.invalidateQueries({ queryKey: ["admin-maintenance"] });
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Yêu cầu sửa chữa</h1>
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="pending">Chờ</TabsTrigger>
          <TabsTrigger value="in_progress">Đang xử lý</TabsTrigger>
          <TabsTrigger value="resolved">Đã xong</TabsTrigger>
          <TabsTrigger value="all">Tất cả</TabsTrigger>
        </TabsList>
        <TabsContent value={tab} className="space-y-3 mt-4">
          {isLoading && <div className="text-muted-foreground">Đang tải...</div>}
          {!isLoading && items?.length === 0 && <div className="text-muted-foreground">Không có yêu cầu nào.</div>}
          {items?.map((r: any) => {
            const s = statusLabel[r.status];
            const p = priorityLabel[r.priority];
            return (
              <div key={r.id} className="bg-card border border-border rounded-xl p-4" style={{ boxShadow: "var(--shadow-card)" }}>
                <div className="flex justify-between items-start mb-2 gap-2">
                  <div className="min-w-0">
                    <h3 className="font-semibold">{r.title}</h3>
                    <p className="text-xs text-muted-foreground">
                      {r.profile?.full_name || "—"} · {r.profile?.student_code || "—"} · {r.profile?.phone || "—"}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {r.room ? `Phòng ${r.room.room_number} · Tòa ${r.room.building}` : "Chưa có phòng"} · {categoryLabel[r.category]} · <span className={p.className}>{p.label}</span>
                    </p>
                  </div>
                  <Badge variant={s.variant}>{s.label}</Badge>
                </div>
                <p className="text-sm mb-2 whitespace-pre-wrap">{r.description}</p>
                {r.image_urls && r.image_urls.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-2">
                    {r.image_urls.map((url: string) => (
                      <SignedImage key={url} bucket="maintenance-images" value={url} openOnClick wrapperClassName="block w-24 h-24 rounded-lg overflow-hidden border border-border" alt="bằng chứng" className="w-full h-full object-cover" />
                    ))}
                  </div>
                )}
                {r.admin_note && <p className="text-sm bg-muted p-2 rounded mb-2"><span className="text-muted-foreground">Phản hồi: </span>{r.admin_note}</p>}
                <p className="text-xs text-muted-foreground">Gửi: {new Date(r.created_at).toLocaleString("vi-VN")}</p>
                {r.status !== "resolved" && r.status !== "cancelled" && (
                  <Button size="sm" className="mt-3" onClick={() => { setEditing(r); setNewStatus(r.status === "pending" ? "in_progress" : r.status); setAdminNote(r.admin_note ?? ""); }}>
                    Cập nhật
                  </Button>
                )}
              </div>
            );
          })}
        </TabsContent>
      </Tabs>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Cập nhật yêu cầu</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Trạng thái</Label>
              <Select value={newStatus} onValueChange={setNewStatus}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="in_progress">Đang xử lý</SelectItem>
                  <SelectItem value="resolved">Đã xong</SelectItem>
                  <SelectItem value="rejected">Từ chối</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Ghi chú phản hồi</Label>
              <Textarea value={adminNote} onChange={(e) => setAdminNote(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditing(null)}>Hủy</Button>
            <Button onClick={save}>Lưu</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
