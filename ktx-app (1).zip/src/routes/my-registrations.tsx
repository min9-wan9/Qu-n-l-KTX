import { SignedImage } from "@/components/SignedImage";
import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export const Route = createFileRoute("/my-registrations")({
  component: () => <ProtectedRoute><MyRegs /></ProtectedRoute>,
});

const statusLabel: Record<string, { label: string; variant: any }> = {
  pending: { label: "Đang chờ", variant: "secondary" },
  approved: { label: "Đã duyệt", variant: "default" },
  rejected: { label: "Từ chối", variant: "destructive" },
  cancelled: { label: "Đã hủy", variant: "outline" },
};

const categoryLabel: Record<string, string> = {
  hardship: "Hoàn cảnh khó khăn",
  academic: "Xét GPA & Điểm rèn luyện",
  gpa: "Xét GPA",
  conduct: "Điểm rèn luyện",
};

function MyRegs() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const { data: regs, isLoading } = useQuery({
    queryKey: ["my-regs", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("registrations")
        .select("*, rooms(room_number, building, floor, monthly_price, room_type)")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
    enabled: !!user,
  });

  const cancel = async (id: string) => {
    const { error } = await supabase.from("registrations").update({ status: "cancelled" }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Đã hủy đơn");
    qc.invalidateQueries({ queryKey: ["my-regs"] });
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Đơn đăng ký của tôi</h1>
      {isLoading ? <div>Đang tải...</div> : regs?.length === 0 ? (
        <div className="text-muted-foreground bg-card border border-border rounded-xl p-8 text-center">
          Bạn chưa có đơn đăng ký nào.
        </div>
      ) : (
        <div className="space-y-3">
          {regs?.map((r) => {
            const s = statusLabel[r.status];
            return (
              <div key={r.id} className="bg-card border border-border rounded-xl p-4" style={{ boxShadow: "var(--shadow-card)" }}>
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-semibold">Phòng {r.rooms?.room_number}</h3>
                    <p className="text-xs text-muted-foreground">Tòa {r.rooms?.building} · {Number(r.rooms?.monthly_price).toLocaleString()}đ/th</p>
                  </div>
                  <Badge variant={s.variant}>{s.label}</Badge>
                </div>
                {r.note && <p className="text-sm text-muted-foreground mb-2">Ghi chú: {r.note}</p>}
                {r.category && (
                  <div className="text-sm mb-2">
                    <Badge variant="outline">{categoryLabel[r.category]}</Badge>
                    {r.category === "academic" && (
                      <>
                        {r.gpa != null && <span className="ml-2">GPA: <strong>{r.gpa}</strong></span>}
                        {r.conduct_score != null && <span className="ml-2">ĐRL: <strong>{r.conduct_score}</strong></span>}
                      </>
                    )}
                    {r.category === "gpa" && r.gpa != null && <span className="ml-2">GPA: <strong>{r.gpa}</strong></span>}
                    {r.category === "conduct" && r.conduct_score != null && <span className="ml-2">ĐRL: <strong>{r.conduct_score}</strong></span>}
                  </div>
                )}
                {r.proof_image_url && (
                  <SignedImage bucket="registration-proofs" value={r.proof_image_url} openOnClick wrapperClassName="block mb-2" alt="Minh chứng" className="max-h-32 rounded border border-border" />
                )}
                {(r.start_date || r.end_date) && (
                  <p className="text-xs text-muted-foreground">Thời hạn ở: {r.start_date} → {r.end_date}</p>
                )}
                {r.admin_note && <p className="text-sm text-foreground bg-muted p-2 rounded">Phản hồi: {r.admin_note}</p>}
                <div className="text-xs text-muted-foreground mt-2">
                  Gửi lúc: {new Date(r.created_at).toLocaleString("vi-VN")}
                </div>
                {r.status === "pending" && (
                  <Button size="sm" variant="outline" className="mt-3" onClick={() => cancel(r.id)}>Hủy đơn</Button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
