import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/lib/auth";
import { toast } from "sonner";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/rooms")({
  component: () => <ProtectedRoute><Rooms /></ProtectedRoute>,
});

const roomTypeLabel: Record<string, string> = { standard: "Tiêu chuẩn", vip: "VIP" };

const CATEGORY_OPTIONS = [
  { value: "hardship", label: "Hoàn cảnh khó khăn" },
  { value: "academic", label: "Xét GPA & Điểm rèn luyện" },
];

function Rooms() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [filter, setFilter] = useState<string>("all");
  const [selected, setSelected] = useState<any>(null);
  const [note, setNote] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [category, setCategory] = useState<string>("");
  const [gpa, setGpa] = useState("");
  const [conductScore, setConductScore] = useState("");
  const [hardshipProof, setHardshipProof] = useState("");
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  const { data: rooms, isLoading } = useQuery({
    queryKey: ["rooms"],
    queryFn: async () => {
      const { data } = await supabase.from("rooms").select("*").order("room_number");
      return data ?? [];
    },
  });

  const filtered = rooms?.filter((r) => filter === "all" || r.room_type === filter) ?? [];

  const register = async () => {
    if (!selected || !user) return;
    if (!category) return toast.error("Vui lòng chọn diện xét");
    if (category === "academic") {
      const g = parseFloat(gpa);
      if (isNaN(g) || g < 0 || g > 4) return toast.error("GPA phải trong khoảng 0 - 4");
      const c = parseInt(conductScore);
      if (isNaN(c) || c < 0 || c > 100) return toast.error("Điểm rèn luyện 0 - 100");
    }
    if (category === "hardship" && hardshipProof.trim().length < 5) {
      return toast.error("Vui lòng mô tả minh chứng hoàn cảnh");
    }
    if (!proofFile) return toast.error("Vui lòng tải lên ảnh minh chứng");
    setSubmitting(true);
    const { data: existing } = await supabase
      .from("registrations")
      .select("id")
      .eq("user_id", user.id)
      .eq("room_id", selected.id)
      .in("status", ["pending", "approved"])
      .maybeSingle();
    if (existing) {
      setSubmitting(false);
      toast.error("Bạn đã có đơn đăng ký phòng này rồi");
      return;
    }
    // Upload ảnh minh chứng
    setUploading(true);
    const ext = proofFile.name.split(".").pop() || "jpg";
    const path = `${user.id}/${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage
      .from("registration-proofs")
      .upload(path, proofFile, { upsert: false });
    setUploading(false);
    if (upErr) {
      setSubmitting(false);
      return toast.error("Tải ảnh thất bại: " + upErr.message);
    }
    const proofUrl = path;
    const today = new Date();
    const end = new Date(today);
    end.setFullYear(end.getFullYear() + 1);
    const { error } = await supabase.from("registrations").insert({
      user_id: user.id,
      room_id: selected.id,
      note,
      status: "pending",
      category: category as any,
      gpa: category === "academic" ? parseFloat(gpa) : null,
      conduct_score: category === "academic" ? parseInt(conductScore) : null,
      hardship_proof: category === "hardship" ? hardshipProof : null,
      proof_image_url: proofUrl,
      start_date: today.toISOString().slice(0, 10),
      end_date: end.toISOString().slice(0, 10),
    });
    setSubmitting(false);
    if (error) return toast.error(error.message);
    toast.success("Đã gửi đơn đăng ký!");
    setSelected(null);
    setNote("");
    setCategory(""); setGpa(""); setConductScore(""); setHardshipProof(""); setProofFile(null);
    qc.invalidateQueries({ queryKey: ["my-regs"] });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold">Danh sách phòng</h1>
          <p className="text-sm text-muted-foreground">Chọn phòng để đăng ký</p>
        </div>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tất cả</SelectItem>
            <SelectItem value="standard">Tiêu chuẩn</SelectItem>
            <SelectItem value="vip">VIP</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="text-muted-foreground">Đang tải...</div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((r) => {
            const full = r.current_occupancy >= r.capacity;
            return (
              <div key={r.id} className="bg-card border border-border rounded-xl p-5" style={{ boxShadow: "var(--shadow-card)" }}>
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="font-bold text-lg">Phòng {r.room_number}</h3>
                    <p className="text-xs text-muted-foreground">Tòa {r.building} · Tầng {r.floor}</p>
                  </div>
                  <Badge variant={full ? "destructive" : "secondary"}>{full ? "Đầy" : "Còn chỗ"}</Badge>
                </div>
                <div className="space-y-1 text-sm mb-4">
                  <div>Loại: <strong>{roomTypeLabel[r.room_type]}</strong></div>
                  <div>Số người: <strong>{r.current_occupancy}/{r.capacity}</strong></div>
                  <div>Giá: <strong className="text-primary">{Number(r.monthly_price).toLocaleString()}đ/tháng</strong></div>
                  {r.description && <div className="text-xs text-muted-foreground">{r.description}</div>}
                  {r.facilities?.length > 0 && (
                    <div className="pt-2">
                      <div className="text-xs font-semibold mb-1">Cơ sở vật chất:</div>
                      <div className="flex flex-wrap gap-1">
                        {r.facilities.map((f: string) => (
                          <Badge key={f} variant="outline" className="text-[10px] font-normal">{f}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                <Dialog open={selected?.id === r.id} onOpenChange={(o) => !o && setSelected(null)}>
                  <DialogTrigger asChild>
                    <Button className="w-full" disabled={full} onClick={() => setSelected(r)}>
                      {full ? "Đã đầy" : "Đăng ký"}
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader><DialogTitle>Đăng ký phòng {r.room_number}</DialogTitle></DialogHeader>
                    <div className="space-y-3">
                      <div>
                        <Label>Diện xét đăng ký *</Label>
                        <Select value={category} onValueChange={setCategory}>
                          <SelectTrigger><SelectValue placeholder="Chọn diện xét" /></SelectTrigger>
                          <SelectContent>
                            {CATEGORY_OPTIONS.map((c) => (
                              <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      {category === "academic" && (
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <Label>GPA (0 - 4)</Label>
                            <Input type="number" step="0.01" min="0" max="4" value={gpa} onChange={(e) => setGpa(e.target.value)} />
                          </div>
                          <div>
                            <Label>Điểm rèn luyện (0 - 100)</Label>
                            <Input type="number" min="0" max="100" value={conductScore} onChange={(e) => setConductScore(e.target.value)} />
                          </div>
                        </div>
                      )}
                      {category === "hardship" && (
                        <div>
                          <Label>Minh chứng hoàn cảnh khó khăn</Label>
                          <Textarea placeholder="Mô tả hoàn cảnh, giấy tờ kèm theo..." value={hardshipProof} onChange={(e) => setHardshipProof(e.target.value)} maxLength={1000} />
                        </div>
                      )}
                      {category && (
                        <div>
                          <Label>Ảnh minh chứng *</Label>
                          <Input type="file" accept="image/*" onChange={(e) => setProofFile(e.target.files?.[0] ?? null)} />
                          {proofFile && (
                            <p className="text-xs text-muted-foreground mt-1">Đã chọn: {proofFile.name}</p>
                          )}
                          <p className="text-xs text-muted-foreground mt-1">
                            {category === "hardship"
                              ? "Ảnh giấy xác nhận hộ nghèo / hoàn cảnh khó khăn"
                              : "Ảnh bảng điểm hoặc xác nhận điểm rèn luyện"}
                          </p>
                        </div>
                      )}
                      <div className="text-xs text-muted-foreground bg-muted p-2 rounded">
                        Thời hạn ở: <strong>1 năm học</strong> kể từ ngày được duyệt.
                      </div>
                      <Textarea placeholder="Ghi chú (tùy chọn)" value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} />
                    </div>
                    <DialogFooter>
                      <Button variant="ghost" onClick={() => setSelected(null)}>Hủy</Button>
                      <Button onClick={register} disabled={submitting || uploading}>
                        {uploading ? "Đang tải ảnh..." : submitting ? "Đang gửi..." : "Gửi đơn"}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
