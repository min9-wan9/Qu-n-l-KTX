import { createFileRoute, Link } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Building2, Bell, FileText, Home, Info, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/dashboard")({
  component: () => <ProtectedRoute><Dashboard /></ProtectedRoute>,
});

function Dashboard() {
  const { user } = useAuth();
  const { data: profile } = useQuery({
    queryKey: ["profile", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("*").eq("id", user!.id).maybeSingle();
      return data;
    },
    enabled: !!user,
  });
  const { data: assignment } = useQuery({
    queryKey: ["my-assignment", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("room_assignments")
        .select("*, rooms(*)")
        .eq("user_id", user!.id)
        .eq("is_active", true)
        .maybeSingle();
      return data;
    },
    enabled: !!user,
  });
  const { data: regs } = useQuery({
    queryKey: ["my-regs", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("registrations")
        .select("*, rooms(room_number)")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
    enabled: !!user,
  });
  const { data: unreadCount } = useQuery({
    queryKey: ["unread-notifs", user?.id],
    queryFn: async () => {
      const { count } = await supabase
        .from("notifications")
        .select("*", { count: "exact", head: true })
        .eq("user_id", user!.id)
        .eq("is_read", false);
      return count ?? 0;
    },
    enabled: !!user,
  });

  const pendingRegs = regs?.filter((r) => r.status === "pending").length ?? 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Xin chào, {profile?.full_name || "Sinh viên"} 👋</h1>
        <p className="text-muted-foreground text-sm">Tổng quan tài khoản của bạn</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={Home} label="Phòng hiện tại" value={assignment?.rooms?.room_number ?? "Chưa có"} link="/profile" />
        <StatCard icon={FileText} label="Đơn đang chờ" value={String(pendingRegs)} link="/my-registrations" />
        <StatCard icon={Bell} label="Thông báo mới" value={String(unreadCount ?? 0)} link="/notifications" />
        <StatCard icon={Building2} label="Xem phòng" value="Tìm phòng" link="/rooms" />
      </div>

      {assignment ? (
        <div className="bg-card border border-border rounded-xl p-5" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold">Phòng của tôi</h2>
            <Badge>Đã nhận phòng</Badge>
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div><span className="text-muted-foreground">Phòng:</span> <strong>{assignment.rooms?.room_number}</strong></div>
            <div><span className="text-muted-foreground">Tòa:</span> {assignment.rooms?.building}</div>
            <div><span className="text-muted-foreground">Tầng:</span> {assignment.rooms?.floor}</div>
            <div><span className="text-muted-foreground">Giá/tháng:</span> {Number(assignment.rooms?.monthly_price).toLocaleString()}đ</div>
            <div><span className="text-muted-foreground">Ngày vào:</span> {assignment.check_in_date}</div>
          </div>
        </div>
      ) : (
        <div className="bg-card border border-border rounded-xl p-5 space-y-3" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex items-start gap-3">
            <div className="rounded-lg bg-primary/10 text-primary p-2"><Info className="h-5 w-5" /></div>
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-semibold">Bạn chưa được phân phòng</h2>
                {pendingRegs > 0 && <Badge variant="secondary">Đang chờ duyệt {pendingRegs} đơn</Badge>}
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {pendingRegs > 0
                  ? "Đơn đăng ký của bạn đang được Ban quản lý xem xét. Bạn sẽ nhận được thông báo khi có kết quả."
                  : "Hãy đăng ký một phòng để bắt đầu sử dụng các tiện ích như hóa đơn, yêu cầu sửa chữa…"}
              </p>
            </div>
          </div>
          <ol className="text-sm space-y-1 list-decimal pl-5 text-muted-foreground">
            <li>Vào <strong className="text-foreground">Danh sách phòng</strong> để xem phòng còn chỗ.</li>
            <li>Chọn phòng phù hợp và bấm <strong className="text-foreground">Đăng ký</strong>.</li>
            <li>Theo dõi trạng thái đơn ở <strong className="text-foreground">Đơn của tôi</strong> và Thông báo.</li>
          </ol>
          <div className="flex gap-2 flex-wrap pt-1">
            <Link to="/rooms"><Button size="sm"><Home className="h-4 w-4 mr-1" />Xem phòng còn chỗ<ArrowRight className="h-4 w-4 ml-1" /></Button></Link>
            <Link to="/my-registrations"><Button size="sm" variant="outline">Đơn của tôi</Button></Link>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, link }: { icon: any; label: string; value: string; link: string }) {
  return (
    <Link to={link} className="bg-card border border-border rounded-xl p-4 hover:border-primary transition-colors" style={{ boxShadow: "var(--shadow-card)" }}>
      <Icon className="h-5 w-5 text-primary mb-2" />
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-lg font-bold mt-1 truncate">{value}</div>
    </Link>
  );
}
