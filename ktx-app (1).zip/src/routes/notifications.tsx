import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Bell, BellRing } from "lucide-react";

export const Route = createFileRoute("/notifications")({
  component: () => <ProtectedRoute><Notifs /></ProtectedRoute>,
});

function Notifs() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const { data: notifs, isLoading } = useQuery({
    queryKey: ["notifs", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("notifications")
        .select("*")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
    enabled: !!user,
  });

  const markRead = async (id: string) => {
    await supabase.from("notifications").update({ is_read: true }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["notifs"] });
    qc.invalidateQueries({ queryKey: ["unread-notifs"] });
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Thông báo</h1>
      {isLoading ? <div>Đang tải...</div> : notifs?.length === 0 ? (
        <div className="text-muted-foreground bg-card border border-border rounded-xl p-8 text-center">
          Chưa có thông báo nào.
        </div>
      ) : (
        <div className="space-y-2">
          {notifs?.map((n) => (
            <div
              key={n.id}
              onClick={() => !n.is_read && markRead(n.id)}
              className={`bg-card border rounded-xl p-4 cursor-pointer transition-colors ${
                n.is_read ? "border-border" : "border-primary bg-primary/5"
              }`}
            >
              <div className="flex gap-3">
                {n.is_read ? <Bell className="h-5 w-5 text-muted-foreground shrink-0" /> : <BellRing className="h-5 w-5 text-primary shrink-0" />}
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-sm">{n.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{n.message}</p>
                  <div className="text-xs text-muted-foreground mt-2">{new Date(n.created_at).toLocaleString("vi-VN")}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
