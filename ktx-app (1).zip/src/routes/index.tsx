import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";
import { Building2, ClipboardCheck, Bell, Users } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  component: Landing,
});

function Landing() {
  const { user, role, loading } = useAuth();
  if (loading) return null;
  if (user) return <Navigate to={role === "admin" ? "/admin" : "/dashboard"} />;

  return (
    <div className="min-h-screen bg-background">
      <header className="container mx-auto px-4 py-5 flex items-center justify-between">
        <div className="font-bold text-lg">🏢 KTX Manager</div>
        <div className="flex gap-2">
          <Link to="/login"><Button variant="ghost" size="sm">Đăng nhập</Button></Link>
          <Link to="/register"><Button size="sm">Đăng ký</Button></Link>
        </div>
      </header>

      <section
        className="container mx-auto px-4 py-16 md:py-24 text-center"
        style={{ background: "var(--gradient-hero)", borderRadius: "1.5rem" }}
      >
        <div className="max-w-2xl mx-auto text-primary-foreground">
          <h1 className="text-3xl md:text-5xl font-bold mb-4">
            Quản lý Ký túc xá Sinh viên
          </h1>
          <p className="text-lg opacity-90 mb-8">
            Đăng ký phòng, theo dõi đơn, nhận thông báo — tất cả trong một ứng dụng.
          </p>
          <div className="flex gap-3 justify-center">
            <Link to="/register">
              <Button size="lg" variant="secondary">Đăng ký ngay</Button>
            </Link>
            <Link to="/login">
              <Button size="lg" variant="outline" className="bg-white/10 border-white/30 text-white hover:bg-white/20">
                Đăng nhập
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-16 grid gap-6 md:grid-cols-4">
        {[
          { icon: Building2, title: "Quản lý phòng", desc: "Xem danh sách phòng, tình trạng còn chỗ" },
          { icon: ClipboardCheck, title: "Đăng ký online", desc: "Gửi đơn đăng ký phòng nhanh chóng" },
          { icon: Bell, title: "Thông báo", desc: "Nhận thông báo duyệt đơn, đóng tiền" },
          { icon: Users, title: "Cho admin", desc: "Quản lý sinh viên, duyệt đơn, thống kê" },
        ].map((f, i) => (
          <div key={i} className="bg-card p-6 rounded-xl border border-border" style={{ boxShadow: "var(--shadow-card)" }}>
            <f.icon className="h-8 w-8 text-primary mb-3" />
            <h3 className="font-semibold mb-1">{f.title}</h3>
            <p className="text-sm text-muted-foreground">{f.desc}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
