import { createFileRoute } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export const Route = createFileRoute("/my-bills")({
  component: () => <ProtectedRoute><MyBills /></ProtectedRoute>,
});

const fmt = (n: number) => n.toLocaleString("vi-VN") + " ₫";

const statusBadge: Record<string, { label: string; variant: any }> = {
  unpaid: { label: "Chưa TT", variant: "secondary" },
  partial: { label: "Một phần", variant: "outline" },
  paid: { label: "Đã TT", variant: "default" },
  overdue: { label: "Quá hạn", variant: "destructive" },
};

const methodLabel: Record<string, string> = {
  cash: "Tiền mặt",
  bank_transfer: "Chuyển khoản",
  momo: "MoMo",
  other: "Khác",
};

function MyBills() {
  const { user } = useAuth();

  const { data: bills, isLoading } = useQuery({
    queryKey: ["my-bills", user?.id],
    queryFn: async () => {
      const { data: bs } = await supabase.from("bills").select("*").eq("user_id", user!.id).order("created_at", { ascending: false });
      if (!bs?.length) return [];
      const billIds = bs.map((b) => b.id);
      const roomIds = [...new Set(bs.map((b) => b.room_id))];
      const [{ data: pays }, { data: rooms }] = await Promise.all([
        supabase.from("payments").select("*").in("bill_id", billIds).order("paid_at", { ascending: false }),
        supabase.from("rooms").select("id, room_number").in("id", roomIds),
      ]);
      const rMap = new Map((rooms ?? []).map((r) => [r.id, r]));
      return bs.map((b) => ({
        ...b,
        room: rMap.get(b.room_id),
        payments: (pays ?? []).filter((p) => p.bill_id === b.id),
      }));
    },
    enabled: !!user,
  });

  const totalUnpaid = bills?.reduce((s, b) => s + (Number(b.total_amount) - Number(b.paid_amount)), 0) ?? 0;

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Hóa đơn của tôi</h1>

      {totalUnpaid > 0 && (
        <div className="bg-card border border-border rounded-xl p-4" style={{ boxShadow: "var(--shadow-card)" }}>
          <p className="text-sm text-muted-foreground">Tổng còn phải thanh toán</p>
          <p className="text-2xl font-bold text-destructive">{fmt(totalUnpaid)}</p>
        </div>
      )}

      {isLoading && <p className="text-muted-foreground">Đang tải...</p>}
      {!isLoading && bills?.length === 0 && <p className="text-muted-foreground">Chưa có hóa đơn nào.</p>}

      <Accordion type="single" collapsible className="space-y-2">
        {bills?.map((b: any) => {
          const s = statusBadge[b.status];
          const remaining = Number(b.total_amount) - Number(b.paid_amount);
          return (
            <AccordionItem key={b.id} value={b.id} className="bg-card border border-border rounded-xl px-4" style={{ boxShadow: "var(--shadow-card)" }}>
              <AccordionTrigger className="hover:no-underline">
                <div className="flex-1 flex justify-between items-center pr-3">
                  <div className="text-left">
                    <p className="font-semibold">Kỳ {b.period} · P.{b.room?.room_number ?? "—"}</p>
                    <p className="text-xs text-muted-foreground">Tổng: {fmt(Number(b.total_amount))} · Còn: <span className="text-destructive font-semibold">{fmt(remaining)}</span></p>
                  </div>
                  <Badge variant={s.variant}>{s.label}</Badge>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2 text-sm">
                  <div className="grid grid-cols-2 gap-2">
                    <div><span className="text-muted-foreground">Tiền phòng:</span> {fmt(Number(b.room_fee))}</div>
                    <div><span className="text-muted-foreground">Phí khác:</span> {fmt(Number(b.other_fee))}</div>
                    <div><span className="text-muted-foreground">Điện:</span> {b.electricity_new - b.electricity_old} kWh × {fmt(Number(b.electricity_rate))} = {fmt((b.electricity_new - b.electricity_old) * Number(b.electricity_rate))}</div>
                    <div><span className="text-muted-foreground">Nước:</span> {b.water_new - b.water_old} m³ × {fmt(Number(b.water_rate))} = {fmt((b.water_new - b.water_old) * Number(b.water_rate))}</div>
                  </div>
                  {b.due_date && <p className="text-xs text-muted-foreground">Hạn TT: {new Date(b.due_date).toLocaleDateString("vi-VN")}</p>}
                  {b.note && <p className="text-xs"><span className="text-muted-foreground">Ghi chú:</span> {b.note}</p>}

                  <div className="border-t border-border pt-2 mt-2">
                    <p className="font-semibold mb-1">Lịch sử thanh toán</p>
                    {b.payments?.length === 0 ? (
                      <p className="text-xs text-muted-foreground">Chưa có thanh toán nào</p>
                    ) : (
                      <ul className="space-y-1">
                        {b.payments?.map((p: any) => (
                          <li key={p.id} className="text-xs flex justify-between bg-muted px-2 py-1 rounded">
                            <span>{new Date(p.paid_at).toLocaleString("vi-VN")} · {methodLabel[p.method]}</span>
                            <span className="font-semibold">{fmt(Number(p.amount))}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          );
        })}
      </Accordion>
    </div>
  );
}
