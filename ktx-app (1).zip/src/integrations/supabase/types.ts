export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      bills: {
        Row: {
          created_at: string
          due_date: string | null
          electricity_new: number
          electricity_old: number
          electricity_rate: number
          id: string
          note: string | null
          other_fee: number
          paid_amount: number
          period: string
          room_fee: number
          room_id: string
          status: Database["public"]["Enums"]["bill_status"]
          total_amount: number
          updated_at: string
          user_id: string
          water_new: number
          water_old: number
          water_rate: number
        }
        Insert: {
          created_at?: string
          due_date?: string | null
          electricity_new?: number
          electricity_old?: number
          electricity_rate?: number
          id?: string
          note?: string | null
          other_fee?: number
          paid_amount?: number
          period: string
          room_fee?: number
          room_id: string
          status?: Database["public"]["Enums"]["bill_status"]
          total_amount?: number
          updated_at?: string
          user_id: string
          water_new?: number
          water_old?: number
          water_rate?: number
        }
        Update: {
          created_at?: string
          due_date?: string | null
          electricity_new?: number
          electricity_old?: number
          electricity_rate?: number
          id?: string
          note?: string | null
          other_fee?: number
          paid_amount?: number
          period?: string
          room_fee?: number
          room_id?: string
          status?: Database["public"]["Enums"]["bill_status"]
          total_amount?: number
          updated_at?: string
          user_id?: string
          water_new?: number
          water_old?: number
          water_rate?: number
        }
        Relationships: []
      }
      maintenance_requests: {
        Row: {
          admin_note: string | null
          category: Database["public"]["Enums"]["maintenance_category"]
          created_at: string
          description: string
          id: string
          image_urls: string[]
          priority: Database["public"]["Enums"]["maintenance_priority"]
          resolved_at: string | null
          room_id: string | null
          status: Database["public"]["Enums"]["maintenance_status"]
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_note?: string | null
          category?: Database["public"]["Enums"]["maintenance_category"]
          created_at?: string
          description: string
          id?: string
          image_urls?: string[]
          priority?: Database["public"]["Enums"]["maintenance_priority"]
          resolved_at?: string | null
          room_id?: string | null
          status?: Database["public"]["Enums"]["maintenance_status"]
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_note?: string | null
          category?: Database["public"]["Enums"]["maintenance_category"]
          created_at?: string
          description?: string
          id?: string
          image_urls?: string[]
          priority?: Database["public"]["Enums"]["maintenance_priority"]
          resolved_at?: string | null
          room_id?: string | null
          status?: Database["public"]["Enums"]["maintenance_status"]
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          is_read: boolean
          message: string
          title: string
          type: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          is_read?: boolean
          message: string
          title: string
          type?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          is_read?: boolean
          message?: string
          title?: string
          type?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      payments: {
        Row: {
          amount: number
          bill_id: string
          created_at: string
          id: string
          method: Database["public"]["Enums"]["payment_method"]
          note: string | null
          paid_at: string
          user_id: string
        }
        Insert: {
          amount: number
          bill_id: string
          created_at?: string
          id?: string
          method?: Database["public"]["Enums"]["payment_method"]
          note?: string | null
          paid_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          bill_id?: string
          created_at?: string
          id?: string
          method?: Database["public"]["Enums"]["payment_method"]
          note?: string | null
          paid_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "payments_bill_id_fkey"
            columns: ["bill_id"]
            isOneToOne: false
            referencedRelation: "bills"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          class_name: string | null
          created_at: string
          email: string | null
          full_name: string
          gender: Database["public"]["Enums"]["gender"] | null
          id: string
          phone: string | null
          student_code: string | null
          updated_at: string
        }
        Insert: {
          class_name?: string | null
          created_at?: string
          email?: string | null
          full_name?: string
          gender?: Database["public"]["Enums"]["gender"] | null
          id: string
          phone?: string | null
          student_code?: string | null
          updated_at?: string
        }
        Update: {
          class_name?: string | null
          created_at?: string
          email?: string | null
          full_name?: string
          gender?: Database["public"]["Enums"]["gender"] | null
          id?: string
          phone?: string | null
          student_code?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      registrations: {
        Row: {
          admin_note: string | null
          category: Database["public"]["Enums"]["registration_category"] | null
          conduct_score: number | null
          created_at: string
          end_date: string | null
          gpa: number | null
          hardship_proof: string | null
          id: string
          note: string | null
          proof_image_url: string | null
          room_id: string
          start_date: string | null
          status: Database["public"]["Enums"]["registration_status"]
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_note?: string | null
          category?: Database["public"]["Enums"]["registration_category"] | null
          conduct_score?: number | null
          created_at?: string
          end_date?: string | null
          gpa?: number | null
          hardship_proof?: string | null
          id?: string
          note?: string | null
          proof_image_url?: string | null
          room_id: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["registration_status"]
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_note?: string | null
          category?: Database["public"]["Enums"]["registration_category"] | null
          conduct_score?: number | null
          created_at?: string
          end_date?: string | null
          gpa?: number | null
          hardship_proof?: string | null
          id?: string
          note?: string | null
          proof_image_url?: string | null
          room_id?: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["registration_status"]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "registrations_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      room_assignments: {
        Row: {
          check_in_date: string
          check_out_date: string | null
          created_at: string
          id: string
          is_active: boolean
          room_id: string
          user_id: string
        }
        Insert: {
          check_in_date?: string
          check_out_date?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          room_id: string
          user_id: string
        }
        Update: {
          check_in_date?: string
          check_out_date?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          room_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "room_assignments_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      rooms: {
        Row: {
          building: string | null
          capacity: number
          created_at: string
          current_occupancy: number
          description: string | null
          facilities: string[]
          floor: number | null
          id: string
          monthly_price: number
          room_number: string
          room_type: Database["public"]["Enums"]["room_type"]
          updated_at: string
        }
        Insert: {
          building?: string | null
          capacity?: number
          created_at?: string
          current_occupancy?: number
          description?: string | null
          facilities?: string[]
          floor?: number | null
          id?: string
          monthly_price?: number
          room_number: string
          room_type?: Database["public"]["Enums"]["room_type"]
          updated_at?: string
        }
        Update: {
          building?: string | null
          capacity?: number
          created_at?: string
          current_occupancy?: number
          description?: string | null
          facilities?: string[]
          floor?: number | null
          id?: string
          monthly_price?: number
          room_number?: string
          room_type?: Database["public"]["Enums"]["room_type"]
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "student"
      bill_status: "unpaid" | "partial" | "paid" | "overdue"
      gender: "male" | "female" | "other"
      maintenance_category:
        | "electricity"
        | "water"
        | "furniture"
        | "internet"
        | "other"
      maintenance_priority: "low" | "medium" | "high"
      maintenance_status:
        | "pending"
        | "in_progress"
        | "resolved"
        | "rejected"
        | "cancelled"
      payment_method: "cash" | "bank_transfer" | "momo" | "other"
      registration_category: "hardship" | "gpa" | "conduct" | "academic"
      registration_status: "pending" | "approved" | "rejected" | "cancelled"
      room_type: "male" | "female" | "vip" | "standard"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "student"],
      bill_status: ["unpaid", "partial", "paid", "overdue"],
      gender: ["male", "female", "other"],
      maintenance_category: [
        "electricity",
        "water",
        "furniture",
        "internet",
        "other",
      ],
      maintenance_priority: ["low", "medium", "high"],
      maintenance_status: [
        "pending",
        "in_progress",
        "resolved",
        "rejected",
        "cancelled",
      ],
      payment_method: ["cash", "bank_transfer", "momo", "other"],
      registration_category: ["hardship", "gpa", "conduct", "academic"],
      registration_status: ["pending", "approved", "rejected", "cancelled"],
      room_type: ["male", "female", "vip", "standard"],
    },
  },
} as const
