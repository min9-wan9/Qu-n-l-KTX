-- Enums
CREATE TYPE public.app_role AS ENUM ('admin', 'student');
CREATE TYPE public.room_type AS ENUM ('male', 'female', 'vip', 'standard');
CREATE TYPE public.registration_status AS ENUM ('pending', 'approved', 'rejected', 'cancelled');
CREATE TYPE public.gender AS ENUM ('male', 'female', 'other');
CREATE TYPE public.bill_status AS ENUM ('unpaid', 'partial', 'paid', 'overdue');
CREATE TYPE public.payment_method AS ENUM ('cash', 'bank_transfer', 'momo', 'other');
CREATE TYPE public.maintenance_category AS ENUM ('electricity', 'water', 'furniture', 'internet', 'other');
CREATE TYPE public.maintenance_priority AS ENUM ('low', 'medium', 'high');
CREATE TYPE public.maintenance_status AS ENUM ('pending', 'in_progress', 'resolved', 'rejected', 'cancelled');

-- profiles
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL DEFAULT '',
  student_code TEXT,
  class_name TEXT,
  phone TEXT,
  gender public.gender,
  email TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- user_roles
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- rooms
CREATE TABLE public.rooms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  room_number TEXT NOT NULL UNIQUE,
  room_type public.room_type NOT NULL DEFAULT 'standard',
  capacity INT NOT NULL DEFAULT 4,
  current_occupancy INT NOT NULL DEFAULT 0,
  monthly_price NUMERIC(12,2) NOT NULL DEFAULT 0,
  description TEXT,
  building TEXT,
  floor INT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;

-- registrations
CREATE TABLE public.registrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  status public.registration_status NOT NULL DEFAULT 'pending',
  note TEXT,
  admin_note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.registrations ENABLE ROW LEVEL SECURITY;

-- room_assignments
CREATE TABLE public.room_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  check_in_date DATE NOT NULL DEFAULT CURRENT_DATE,
  check_out_date DATE,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.room_assignments ENABLE ROW LEVEL SECURITY;

-- notifications
CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT DEFAULT 'info',
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- bills
CREATE TABLE public.bills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  room_id UUID NOT NULL,
  period TEXT NOT NULL,
  room_fee NUMERIC NOT NULL DEFAULT 0,
  electricity_old INTEGER NOT NULL DEFAULT 0,
  electricity_new INTEGER NOT NULL DEFAULT 0,
  electricity_rate NUMERIC NOT NULL DEFAULT 3500,
  water_old INTEGER NOT NULL DEFAULT 0,
  water_new INTEGER NOT NULL DEFAULT 0,
  water_rate NUMERIC NOT NULL DEFAULT 15000,
  other_fee NUMERIC NOT NULL DEFAULT 0,
  total_amount NUMERIC NOT NULL DEFAULT 0,
  paid_amount NUMERIC NOT NULL DEFAULT 0,
  due_date DATE,
  status public.bill_status NOT NULL DEFAULT 'unpaid',
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_bills_user ON public.bills(user_id);
CREATE INDEX idx_bills_room ON public.bills(room_id);
ALTER TABLE public.bills ENABLE ROW LEVEL SECURITY;

-- payments
CREATE TABLE public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id UUID NOT NULL REFERENCES public.bills(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  amount NUMERIC NOT NULL,
  method public.payment_method NOT NULL DEFAULT 'cash',
  paid_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_payments_bill ON public.payments(bill_id);
CREATE INDEX idx_payments_user ON public.payments(user_id);
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

-- maintenance_requests
CREATE TABLE public.maintenance_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  room_id uuid,
  title text NOT NULL,
  description text NOT NULL,
  category public.maintenance_category NOT NULL DEFAULT 'other',
  priority public.maintenance_priority NOT NULL DEFAULT 'medium',
  status public.maintenance_status NOT NULL DEFAULT 'pending',
  admin_note text,
  resolved_at timestamptz,
  image_urls text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_maintenance_user ON public.maintenance_requests(user_id);
CREATE INDEX idx_maintenance_status ON public.maintenance_requests(status);
ALTER TABLE public.maintenance_requests ENABLE ROW LEVEL SECURITY;

-- updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_rooms_updated BEFORE UPDATE ON public.rooms FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_registrations_updated BEFORE UPDATE ON public.registrations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_bills_updated_at BEFORE UPDATE ON public.bills FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_maintenance_updated_at BEFORE UPDATE ON public.maintenance_requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Auto-create profile + default role
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), NEW.email);
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'student');
  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- RLS POLICIES
CREATE POLICY "Users view own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Admin views all profiles" ON public.profiles FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Admin updates any profile" ON public.profiles FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users view own roles" ON public.user_roles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Admin views all roles" ON public.user_roles FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin manages roles" ON public.user_roles FOR ALL USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Authenticated view rooms" ON public.rooms FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admin manages rooms" ON public.rooms FOR ALL USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users view own regs" ON public.registrations FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Admin views all regs" ON public.registrations FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users create own regs" ON public.registrations FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users cancel own regs" ON public.registrations FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Admin updates regs" ON public.registrations FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin deletes regs" ON public.registrations FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users view own assignments" ON public.room_assignments FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Admin views all assignments" ON public.room_assignments FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin manages assignments" ON public.room_assignments FOR ALL USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users view own notifs" ON public.notifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users update own notifs" ON public.notifications FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Admin views all notifs" ON public.notifications FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin manages notifs" ON public.notifications FOR ALL USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admin manages bills" ON public.bills FOR ALL USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Users view own bills" ON public.bills FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admin manages payments" ON public.payments FOR ALL USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Users view own payments" ON public.payments FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users view own maintenance" ON public.maintenance_requests FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users create own maintenance" ON public.maintenance_requests FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users cancel own maintenance" ON public.maintenance_requests FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Admin views all maintenance" ON public.maintenance_requests FOR SELECT USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin manages maintenance" ON public.maintenance_requests FOR ALL USING (has_role(auth.uid(), 'admin'));

-- Unique active registration
CREATE UNIQUE INDEX registrations_unique_active ON public.registrations (user_id, room_id)
WHERE status IN ('pending', 'approved');

-- Realtime
ALTER TABLE public.registrations REPLICA IDENTITY FULL;
ALTER TABLE public.bills REPLICA IDENTITY FULL;
ALTER TABLE public.payments REPLICA IDENTITY FULL;
ALTER TABLE public.room_assignments REPLICA IDENTITY FULL;
ALTER TABLE public.maintenance_requests REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.registrations;
ALTER PUBLICATION supabase_realtime ADD TABLE public.bills;
ALTER PUBLICATION supabase_realtime ADD TABLE public.payments;
ALTER PUBLICATION supabase_realtime ADD TABLE public.room_assignments;
ALTER PUBLICATION supabase_realtime ADD TABLE public.maintenance_requests;

-- Function permissions
REVOKE EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

-- Seed sample rooms
INSERT INTO public.rooms (room_number, room_type, capacity, monthly_price, building, floor, description) VALUES
('A101', 'male', 4, 800000, 'A', 1, 'Phòng nam tiêu chuẩn 4 người'),
('A102', 'male', 4, 800000, 'A', 1, 'Phòng nam tiêu chuẩn 4 người'),
('A201', 'male', 6, 600000, 'A', 2, 'Phòng nam 6 người'),
('B101', 'female', 4, 800000, 'B', 1, 'Phòng nữ tiêu chuẩn 4 người'),
('B102', 'female', 4, 800000, 'B', 1, 'Phòng nữ tiêu chuẩn 4 người'),
('C101', 'vip', 2, 1500000, 'C', 1, 'Phòng VIP 2 người, máy lạnh'),
('C102', 'vip', 2, 1500000, 'C', 1, 'Phòng VIP 2 người, máy lạnh');

-- Storage bucket for maintenance images
INSERT INTO storage.buckets (id, name, public) VALUES ('maintenance-images', 'maintenance-images', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public read maintenance images" ON storage.objects
  FOR SELECT USING (bucket_id = 'maintenance-images');
CREATE POLICY "Users upload own maintenance images" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'maintenance-images' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users delete own maintenance images" ON storage.objects
  FOR DELETE USING (bucket_id = 'maintenance-images' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Admin manages maintenance images" ON storage.objects
  FOR ALL USING (bucket_id = 'maintenance-images' AND has_role(auth.uid(), 'admin'));