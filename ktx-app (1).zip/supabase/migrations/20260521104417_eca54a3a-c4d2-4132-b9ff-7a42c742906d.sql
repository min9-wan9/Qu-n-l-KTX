
ALTER TABLE public.rooms ADD COLUMN IF NOT EXISTS facilities text[] NOT NULL DEFAULT '{}';

-- Trigger validate capacity in (4,8,12)
CREATE OR REPLACE FUNCTION public.validate_room_capacity()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.capacity NOT IN (4, 8, 12) THEN
    RAISE EXCEPTION 'Sức chứa chỉ được là 4, 8 hoặc 12';
  END IF;
  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS trg_validate_room_capacity ON public.rooms;
CREATE TRIGGER trg_validate_room_capacity
BEFORE INSERT OR UPDATE ON public.rooms
FOR EACH ROW EXECUTE FUNCTION public.validate_room_capacity();

-- Xoá phòng cũ và tạo lại 12 phòng cố định
DELETE FROM public.rooms;

INSERT INTO public.rooms (room_number, room_type, capacity, monthly_price, building, floor, description, facilities) VALUES
('101', 'standard', 8, 800000, 'A', 1, 'Phòng tiêu chuẩn nam tầng 1', ARRAY['Giường tầng','Bàn học','Tủ quần áo','Đèn LED','Quạt trần','Nhà vệ sinh chung']),
('102', 'standard', 8, 800000, 'A', 1, 'Phòng tiêu chuẩn nam tầng 1', ARRAY['Giường tầng','Bàn học','Tủ quần áo','Đèn LED','Quạt trần','Nhà vệ sinh chung']),
('103', 'standard', 12, 700000, 'A', 1, 'Phòng tiêu chuẩn nam đông người', ARRAY['Giường tầng','Bàn học','Tủ quần áo','Đèn LED','Quạt trần','Nhà vệ sinh chung']),
('201', 'standard', 8, 800000, 'A', 2, 'Phòng tiêu chuẩn nữ tầng 2', ARRAY['Giường tầng','Bàn học','Tủ quần áo','Đèn LED','Quạt trần','Nhà vệ sinh khép kín']),
('202', 'standard', 8, 800000, 'A', 2, 'Phòng tiêu chuẩn nữ tầng 2', ARRAY['Giường tầng','Bàn học','Tủ quần áo','Đèn LED','Quạt trần','Nhà vệ sinh khép kín']),
('203', 'standard', 12, 700000, 'A', 2, 'Phòng tiêu chuẩn nữ đông người', ARRAY['Giường tầng','Bàn học','Tủ quần áo','Đèn LED','Quạt trần','Nhà vệ sinh khép kín']),
('301', 'vip', 4, 1500000, 'A', 3, 'Phòng VIP nam ít người', ARRAY['Giường đơn','Bàn học riêng','Tủ quần áo','Đèn LED','Máy lạnh','Nóng lạnh','Nhà vệ sinh khép kín','Wifi tốc độ cao','Tủ lạnh mini']),
('302', 'vip', 4, 1500000, 'A', 3, 'Phòng VIP nam ít người', ARRAY['Giường đơn','Bàn học riêng','Tủ quần áo','Đèn LED','Máy lạnh','Nóng lạnh','Nhà vệ sinh khép kín','Wifi tốc độ cao','Tủ lạnh mini']),
('303', 'vip', 8, 1200000, 'A', 3, 'Phòng VIP nam 8 người', ARRAY['Giường tầng','Bàn học','Tủ quần áo','Đèn LED','Máy lạnh','Nhà vệ sinh khép kín','Wifi tốc độ cao']),
('401', 'vip', 4, 1500000, 'A', 4, 'Phòng VIP nữ ít người', ARRAY['Giường đơn','Bàn học riêng','Tủ quần áo','Đèn LED','Máy lạnh','Nóng lạnh','Nhà vệ sinh khép kín','Wifi tốc độ cao','Tủ lạnh mini']),
('402', 'vip', 4, 1500000, 'A', 4, 'Phòng VIP nữ ít người', ARRAY['Giường đơn','Bàn học riêng','Tủ quần áo','Đèn LED','Máy lạnh','Nóng lạnh','Nhà vệ sinh khép kín','Wifi tốc độ cao','Tủ lạnh mini']),
('403', 'vip', 8, 1200000, 'A', 4, 'Phòng VIP nữ 8 người', ARRAY['Giường tầng','Bàn học','Tủ quần áo','Đèn LED','Máy lạnh','Nhà vệ sinh khép kín','Wifi tốc độ cao']);
