
-- Add 'academic' to enum
ALTER TYPE registration_category ADD VALUE IF NOT EXISTS 'academic';

-- Add proof_image_url column
ALTER TABLE public.registrations
  ADD COLUMN IF NOT EXISTS proof_image_url text;

-- Update validation trigger: 2 cases (hardship | academic)
CREATE OR REPLACE FUNCTION public.validate_registration_category()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
BEGIN
  IF NEW.category IS NULL THEN
    RAISE EXCEPTION 'Phải chọn diện xét đăng ký';
  END IF;

  IF NEW.category = 'academic' THEN
    IF NEW.gpa IS NULL OR NEW.gpa < 0 OR NEW.gpa > 4 THEN
      RAISE EXCEPTION 'GPA phải nằm trong khoảng 0 - 4';
    END IF;
    IF NEW.conduct_score IS NULL OR NEW.conduct_score < 0 OR NEW.conduct_score > 100 THEN
      RAISE EXCEPTION 'Điểm rèn luyện phải nằm trong khoảng 0 - 100';
    END IF;
  END IF;

  IF NEW.category = 'hardship' AND (NEW.hardship_proof IS NULL OR length(trim(NEW.hardship_proof)) < 5) THEN
    RAISE EXCEPTION 'Cần mô tả minh chứng hoàn cảnh khó khăn';
  END IF;

  IF NEW.proof_image_url IS NULL OR length(trim(NEW.proof_image_url)) = 0 THEN
    RAISE EXCEPTION 'Cần tải lên ảnh minh chứng';
  END IF;

  IF NEW.start_date IS NULL THEN
    NEW.start_date := CURRENT_DATE;
  END IF;
  IF NEW.end_date IS NULL THEN
    NEW.end_date := NEW.start_date + INTERVAL '1 year';
  END IF;
  RETURN NEW;
END $function$;

-- Create trigger if missing
DROP TRIGGER IF EXISTS trg_validate_registration_category ON public.registrations;
CREATE TRIGGER trg_validate_registration_category
  BEFORE INSERT OR UPDATE ON public.registrations
  FOR EACH ROW EXECUTE FUNCTION public.validate_registration_category();

-- Storage bucket for proof images
INSERT INTO storage.buckets (id, name, public)
VALUES ('registration-proofs', 'registration-proofs', true)
ON CONFLICT (id) DO NOTHING;

-- RLS policies on storage.objects for this bucket
DROP POLICY IF EXISTS "Public read registration proofs" ON storage.objects;
CREATE POLICY "Public read registration proofs"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'registration-proofs');

DROP POLICY IF EXISTS "Users upload own registration proofs" ON storage.objects;
CREATE POLICY "Users upload own registration proofs"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'registration-proofs'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

DROP POLICY IF EXISTS "Users update own registration proofs" ON storage.objects;
CREATE POLICY "Users update own registration proofs"
  ON storage.objects FOR UPDATE
  USING (
    bucket_id = 'registration-proofs'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );
