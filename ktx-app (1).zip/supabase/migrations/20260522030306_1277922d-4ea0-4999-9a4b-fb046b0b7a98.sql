
-- Enum loại diện xét
DO $$ BEGIN
  CREATE TYPE public.registration_category AS ENUM ('hardship', 'gpa', 'conduct');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.registrations
  ADD COLUMN IF NOT EXISTS category public.registration_category,
  ADD COLUMN IF NOT EXISTS gpa numeric(3,2),
  ADD COLUMN IF NOT EXISTS conduct_score integer,
  ADD COLUMN IF NOT EXISTS hardship_proof text,
  ADD COLUMN IF NOT EXISTS start_date date,
  ADD COLUMN IF NOT EXISTS end_date date;

-- Validation trigger
CREATE OR REPLACE FUNCTION public.validate_registration_category()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.category IS NULL THEN
    RAISE EXCEPTION 'Phải chọn diện xét đăng ký';
  END IF;
  IF NEW.category = 'gpa' AND (NEW.gpa IS NULL OR NEW.gpa < 0 OR NEW.gpa > 4) THEN
    RAISE EXCEPTION 'GPA phải nằm trong khoảng 0 - 4';
  END IF;
  IF NEW.category = 'conduct' AND (NEW.conduct_score IS NULL OR NEW.conduct_score < 0 OR NEW.conduct_score > 100) THEN
    RAISE EXCEPTION 'Điểm rèn luyện phải nằm trong khoảng 0 - 100';
  END IF;
  IF NEW.category = 'hardship' AND (NEW.hardship_proof IS NULL OR length(trim(NEW.hardship_proof)) < 5) THEN
    RAISE EXCEPTION 'Cần mô tả minh chứng hoàn cảnh khó khăn';
  END IF;
  -- Mặc định 1 năm học nếu chưa có
  IF NEW.start_date IS NULL THEN
    NEW.start_date := CURRENT_DATE;
  END IF;
  IF NEW.end_date IS NULL THEN
    NEW.end_date := NEW.start_date + INTERVAL '1 year';
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_validate_registration_category ON public.registrations;
CREATE TRIGGER trg_validate_registration_category
BEFORE INSERT OR UPDATE ON public.registrations
FOR EACH ROW EXECUTE FUNCTION public.validate_registration_category();
