
-- 1. Make storage buckets private
UPDATE storage.buckets SET public = false WHERE id IN ('maintenance-images','registration-proofs');

-- 2. Drop overly broad public SELECT policies
DROP POLICY IF EXISTS "Public read maintenance images" ON storage.objects;
DROP POLICY IF EXISTS "Public read registration proofs" ON storage.objects;

-- 3. Owner + admin SELECT for maintenance-images
CREATE POLICY "Owner reads own maintenance images"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'maintenance-images'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Admin reads maintenance images"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'maintenance-images'
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
);

-- 4. Owner + admin SELECT for registration-proofs
CREATE POLICY "Owner reads own registration proofs"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'registration-proofs'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Admin reads registration proofs"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'registration-proofs'
  AND public.has_role(auth.uid(), 'admin'::public.app_role)
);

-- 5. Restrict user UPDATE on registrations: only allow cancelling pending row, no field tampering
DROP POLICY IF EXISTS "Users cancel own regs" ON public.registrations;

CREATE OR REPLACE FUNCTION public.guard_registrations_user_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RETURN NEW;
  END IF;
  IF auth.uid() <> OLD.user_id THEN
    RAISE EXCEPTION 'Không có quyền chỉnh sửa đăng ký này';
  END IF;
  IF OLD.status <> 'pending'::registration_status THEN
    RAISE EXCEPTION 'Chỉ có thể hủy đăng ký đang chờ duyệt';
  END IF;
  IF NEW.status <> 'cancelled'::registration_status THEN
    RAISE EXCEPTION 'Chỉ được phép hủy đăng ký';
  END IF;
  -- Force all other fields to remain unchanged
  NEW.user_id        := OLD.user_id;
  NEW.room_id        := OLD.room_id;
  NEW.category       := OLD.category;
  NEW.gpa            := OLD.gpa;
  NEW.conduct_score  := OLD.conduct_score;
  NEW.hardship_proof := OLD.hardship_proof;
  NEW.proof_image_url:= OLD.proof_image_url;
  NEW.start_date     := OLD.start_date;
  NEW.end_date       := OLD.end_date;
  NEW.note           := OLD.note;
  NEW.admin_note     := OLD.admin_note;
  NEW.created_at     := OLD.created_at;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS guard_registrations_user_update ON public.registrations;
CREATE TRIGGER guard_registrations_user_update
BEFORE UPDATE ON public.registrations
FOR EACH ROW EXECUTE FUNCTION public.guard_registrations_user_update();

CREATE POLICY "Users cancel own pending regs"
ON public.registrations FOR UPDATE
USING (auth.uid() = user_id AND status = 'pending'::registration_status)
WITH CHECK (auth.uid() = user_id AND status = 'cancelled'::registration_status);

-- 6. Restrict user UPDATE on maintenance_requests
DROP POLICY IF EXISTS "Users cancel own maintenance" ON public.maintenance_requests;

CREATE OR REPLACE FUNCTION public.guard_maintenance_user_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RETURN NEW;
  END IF;
  IF auth.uid() <> OLD.user_id THEN
    RAISE EXCEPTION 'Không có quyền chỉnh sửa yêu cầu này';
  END IF;
  IF OLD.status <> 'pending'::maintenance_status THEN
    RAISE EXCEPTION 'Chỉ có thể hủy yêu cầu đang chờ xử lý';
  END IF;
  IF NEW.status <> 'cancelled'::maintenance_status THEN
    RAISE EXCEPTION 'Chỉ được phép hủy yêu cầu';
  END IF;
  NEW.user_id     := OLD.user_id;
  NEW.room_id     := OLD.room_id;
  NEW.title       := OLD.title;
  NEW.description := OLD.description;
  NEW.category    := OLD.category;
  NEW.priority    := OLD.priority;
  NEW.image_urls  := OLD.image_urls;
  NEW.admin_note  := OLD.admin_note;
  NEW.resolved_at := OLD.resolved_at;
  NEW.created_at  := OLD.created_at;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS guard_maintenance_user_update ON public.maintenance_requests;
CREATE TRIGGER guard_maintenance_user_update
BEFORE UPDATE ON public.maintenance_requests
FOR EACH ROW EXECUTE FUNCTION public.guard_maintenance_user_update();

CREATE POLICY "Users cancel own pending maintenance"
ON public.maintenance_requests FOR UPDATE
USING (auth.uid() = user_id AND status = 'pending'::maintenance_status)
WITH CHECK (auth.uid() = user_id AND status = 'cancelled'::maintenance_status);
